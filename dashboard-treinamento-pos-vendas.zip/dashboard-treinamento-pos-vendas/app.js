/* ============================================================================
   APP.JS — Dashboard Treinamento Pós-Vendas
   ----------------------------------------------------------------------------
   Arquitetura:
   1) CONFIG_COLUMN_MAP      — mapeamento central de nomes de colunas (ajuste aqui)
   2) CONFIG                 — parâmetros de negócio (pesos, capacidade de turma...)
   3) Estado global + util de UI (loader, toasts)
   4) readExcelFile / normalizeColumns / prepareData (ETL)
   5) Armazenamento colunar (memória enxuta p/ arquivos muito grandes)
   6) Filtros globais (applyGlobalFilters)
   7) Funções de cálculo por aba (calculateIT, calculateAbsenceDays, ...)
   8) Render (renderCharts, renderTables, renderMap) por aba, sob demanda
   9) Bootstrap / listeners

   IMPORTANTE — arquivos muito grandes:
   Os relatórios de acompanhamento de trilhas fornecidos podem conter MILHÕES
   de linhas. Para não travar o navegador, os dados são convertidos para um
   formato colunar (Structure-of-Arrays) logo após a leitura, e nunca mantemos
   os objetos de linha originais em memória.
============================================================================ */

/* ========================================================================
   1) CONFIG_COLUMN_MAP
   Ajuste aqui caso os relatórios exportados pelo LMS mudem o nome de uma
   coluna. Cada campo lógico aceita uma lista de aliases possíveis; o
   primeiro alias encontrado no cabeçalho do arquivo é utilizado.
======================================================================== */
const CONFIG_COLUMN_MAP = {
  trilha: {
    codUnidade:        ['Código da Unidade'],
    unidade:            ['Unidade Associada'],
    usuario:            ['Usuário'],
    cpf:                ['Identificador'],
    cargo:              ['Cargo'],
    codTrilha:          ['Código da Trilha'],
    trilha:             ['Trilha'],
    codRecurso:         ['Código do Recurso'],
    recurso:            ['Recurso'],
    tipoRecurso:        ['Tipo do Recurso'],
    aprovacao:          ['Aprovação'],
    pesoRecurso:        ['Peso do Recurso'],
    modalidade:         ['Modalidade de Curso'],
    dataInicioCarencia: ['Data Início Carência do Recurso'],
    dataFimCarencia:    ['Data Fim Carência do Recurso'],
    situacaoTrilha:     ['Situação da Trilha'],
    cargaHoraria:       ['Carga Horária da Trilha']
  },
  matricula: {
    hierarquia:      ['Hierarquia da Unidade'],
    dealerCode:      ['Número Dealer'],
    usuario:         ['Usuário'],
    cpf:             ['Identificador', 'CPF'],
    situacaoUsuario: ['Situação do Usuário'],
    setor:           ['Setor'],
    cargo:           ['Cargo'],
    codCurso:        ['Código do Curso'],
    curso:           ['Curso'],
    obrigatoriedade: ['Obrigatoriedade'],
    modalidade:      ['Modalidade'],
    turma:           ['Turma'],
    dataMatricula:   ['Data da Matrícula'],
    dataInicio:      ['Data do Início'],
    dataConclusao:   ['Data da Conclusao', 'Data da Conclusão'],
    statusMatricula: ['Status da Matrícula'],
    situacaoAluno:   ['Situação do Aluno'],
    aproveitamento:  ['Aproveitamento'],
    frequencia:      ['Frequência'],
    genero:          ['Gênero'],
    dataNascimento:  ['Data de Nascimento']
  }
};

/* ========================================================================
   2) CONFIG — parâmetros de negócio ajustáveis
======================================================================== */
const CONFIG = {
  // Filtro MASTER "Presencial & Blended" (controlado pelo interruptor no
  // topo do dashboard, ao lado do seletor 2W/4W). Diferente da versão
  // anterior, este filtro NÃO descarta linhas na leitura do arquivo — todas
  // as modalidades ficam armazenadas, e o filtro é aplicado em tempo real
  // sobre TODOS os cálculos e listas via applyGlobalFilters(). Isso permite
  // ligar/desligar sem precisar reenviar os arquivos.
  // Este valor é apenas o estado inicial (ligado = considera somente
  // Presencial e Blended; desligado = considera todas as modalidades,
  // incluindo A Distância, Prova, Síncrono etc.)
  masterPresencialBlendedDefault: true,

  // Pesos do Score de Prioridade (aba 10) — normalizados internamente.
  priorityWeights: {
    diasSemTreinamento: 30,
    pendencias: 30,
    baixoIT: 25,
    baixoTSI: 10,
    baixaParticipacao: 5
  },

  // Capacidade padrão de alunos por turma (aba 12) — ajustável via slider na UI.
  classCapacity: 20,

  // Honda KI fiscal: 01/04 a 31/03. Âncora: KI 103 cobre 01/04/2026–31/03/2027.
  kiAnchorNumber: 103,
  kiAnchorYear: 2026
};

/* ========================================================================
   3) Estado global + utilidades de UI
======================================================================== */
const STATE = {
  segment: '2W',
  activeTab: 'visaogeral',
  dealersByCode: new Map(),     // codigo -> {codigo,nome,cidade,uf,segmento,regiao}
  filters: { uf:'', regiao:'', dealers: new Set(), curso:'', cargo:'', ki:'', dataInicio:'', dataFim:'', masterPresencialBlended: CONFIG.masterPresencialBlendedDefault },
  trilha: null,   // colunar
  matricula: null,// colunar
  filesLoaded: { trilha2W:false, trilha4W:false, matriculas:false },
  charts: {}      // Chart.js instances by canvas id
};

function showLoader(msg){ document.getElementById('loaderText').textContent = msg || 'Processando...'; document.getElementById('loaderOverlay').classList.add('show'); }
function hideLoader(){ document.getElementById('loaderOverlay').classList.remove('show'); }
function toast(msg, type){
  const stack = document.getElementById('toastStack');
  const el = document.createElement('div');
  el.className = 'toast' + (type ? ' ' + type : '');
  el.textContent = msg;
  stack.appendChild(el);
  setTimeout(()=>{ el.remove(); }, 5200);
}
function yieldToUI(){ return new Promise(r => setTimeout(r, 0)); }

/* ========================================================================
   4) ETL — leitura, normalização, preparação
======================================================================== */

/* ========================================================================
   4-A) LEITOR .XLSX EM FLUXO (STREAMING), SEM LIMITE DE MEMÓRIA
   ----------------------------------------------------------------------------
   Um .xlsx é um arquivo ZIP contendo XML. Para arquivos muito grandes (a
   planilha interna pode se expandir para vários GB de XML descompactado),
   carregar tudo de uma vez na memória — como faz o SheetJS por padrão —
   pode estourar a memória do navegador, especialmente em celulares.

   Este leitor faz o processo manualmente e em fluxo (streaming):
   1) Lê só o final do arquivo para localizar o índice do ZIP (Central
      Directory) — não precisa carregar o arquivo inteiro.
   2) Descobre, via xl/workbook.xml + rels, qual é a primeira planilha.
   3) Descompacta SÓ a planilha alvo (via DecompressionStream nativo do
      navegador — "deflate-raw"), em pedaços, e extrai as linhas <row>...
      </row> conforme chegam, chamando onRow() imediatamente e descartando
      o texto já processado. A memória usada não cresce com o tamanho do
      arquivo — só com o tamanho de uma linha por vez.
   4) Se o arquivo usar "shared strings" (xl/sharedStrings.xml) em vez de
      texto embutido em cada célula, essa tabela é carregada por completo
      (é normalmente muito menor que a planilha em si).

   Requer suporte a DecompressionStream (Chrome/Edge/Firefox/Safari atuais,
   disponível desde 2023). Se não houver suporte, ou se o arquivo tiver
   alguma estrutura fora do padrão, o código cai automaticamente para o
   leitor via SheetJS (readExcelFile, abaixo), que exige carregar o arquivo
   inteiro na memória.
======================================================================== */

function supportsStreamingXLSX(){
  return typeof DecompressionStream !== 'undefined' && typeof Blob !== 'undefined' && typeof Blob.prototype.stream === 'function';
}
// helper de leitura de um trecho do arquivo como ArrayBuffer
function file_streamSlice(file, start, end){
  return file.slice(start, end).arrayBuffer();
}

async function zipLocateEntries(file){
  const size = file.size;
  const tailSize = Math.min(size, 65557);
  const tailBuf = new Uint8Array(await file_streamSlice(file, size - tailSize, size));
  const dv = new DataView(tailBuf.buffer);
  let eocdPos = -1;
  for (let i = tailBuf.length - 22; i >= 0; i--){
    if (dv.getUint32(i, true) === 0x06054b50){ eocdPos = i; break; }
  }
  if (eocdPos === -1) throw new Error('Estrutura ZIP inválida (fim do índice central não encontrado).');
  const cdSize = dv.getUint32(eocdPos + 12, true);
  const cdOffset = dv.getUint32(eocdPos + 16, true);

  const cdBuf = new Uint8Array(await file_streamSlice(file, cdOffset, cdOffset + cdSize));
  const cdv = new DataView(cdBuf.buffer);
  const entries = new Map();
  let p = 0;
  const dec = new TextDecoder('utf-8');
  while (p < cdBuf.length){
    if (cdv.getUint32(p, true) !== 0x02014b50) break;
    const method = cdv.getUint16(p+10, true);
    const compSize = cdv.getUint32(p+20, true);
    const uncompSize = cdv.getUint32(p+24, true);
    const nameLen = cdv.getUint16(p+28, true);
    const extraLen = cdv.getUint16(p+30, true);
    const commentLen = cdv.getUint16(p+32, true);
    const localOffset = cdv.getUint32(p+42, true);
    const name = dec.decode(cdBuf.subarray(p+46, p+46+nameLen));
    entries.set(name, { method, compSize, uncompSize, localOffset });
    p += 46 + nameLen + extraLen + commentLen;
  }
  return entries;
}

async function zipEntryDataOffset(file, localOffset){
  const buf = new Uint8Array(await file_streamSlice(file, localOffset, localOffset + 30));
  const dv = new DataView(buf.buffer);
  if (dv.getUint32(0, true) !== 0x04034b50) throw new Error('Cabeçalho local ZIP inválido.');
  const nameLen = dv.getUint16(26, true);
  const extraLen = dv.getUint16(28, true);
  return localOffset + 30 + nameLen + extraLen;
}

// Descompacta uma entrada inteira e devolve o texto completo (usado para
// partes pequenas: workbook.xml, rels, sharedStrings.xml).
async function zipReadEntryText(file, entries, name){
  const entry = entries.get(name);
  if (!entry) return null;
  const dataStart = await zipEntryDataOffset(file, entry.localOffset);
  const raw = file.slice(dataStart, dataStart + entry.compSize);
  if (entry.method === 0) return await raw.text();
  const stream = raw.stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return await new Response(stream).text();
}

// Resolve o caminho real da PRIMEIRA planilha do workbook (nem sempre é
// literalmente "sheet1.xml").
async function resolveFirstSheetPath(file, entries){
  const wbXml = await zipReadEntryText(file, entries, 'xl/workbook.xml');
  const relsXml = await zipReadEntryText(file, entries, 'xl/_rels/workbook.xml.rels');
  if (!wbXml) return 'xl/worksheets/sheet1.xml'; // fallback
  const sheetMatch = wbXml.match(/<sheet[^>]*r:id="(rId\d+)"[^>]*\/?>|<sheet[^>]*\/>/);
  const firstSheetTag = wbXml.match(/<sheet\b[^>]*>/);
  let rId = null;
  if (firstSheetTag){
    const ridm = firstSheetTag[0].match(/r:id="(rId\d+)"/);
    if (ridm) rId = ridm[1];
  }
  if (rId && relsXml){
    const relRe = new RegExp(`<Relationship[^>]*Id="${rId}"[^>]*Target="([^"]+)"`);
    const relm = relsXml.match(relRe);
    if (relm){
      let target = relm[1].replace(/^\.?\//,'');
      if (!target.startsWith('xl/')) target = 'xl/' + target;
      if (entries.has(target)) return target;
    }
  }
  // fallback: primeira entrada que pareça uma planilha
  const candidate = [...entries.keys()].find(k => /^xl\/worksheets\/sheet\d*\.xml$/i.test(k));
  return candidate || 'xl/worksheets/sheet1.xml';
}

// Carrega e interpreta xl/sharedStrings.xml (quando existir), concatenando
// os trechos <t> de cada <si> (inclusive rich text com múltiplos <r>).
function parseSharedStringsXML(xml){
  const list = [];
  const siRe = /<si>([\s\S]*?)<\/si>/g;
  let m;
  while ((m = siRe.exec(xml))){
    const body = m[1];
    let text = '';
    const tRe = /<t[^>]*>([\s\S]*?)<\/t>/g;
    let tm;
    while ((tm = tRe.exec(body))) text += tm[1];
    list.push(text.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1'));
  }
  return list;
}

// Extrator de linhas <row>...</row> a partir de texto recebido em pedaços,
// com memória limitada ao tamanho de uma linha (não ao arquivo inteiro).
const XLSX_CELL_RE = /<c r="([A-Z]+)\d+"([^>]*)(?:\/>|>([\s\S]*?)<\/c>)/g;
function xlsxColNum(c){ let n=0; for (let i=0;i<c.length;i++) n = n*26 + (c.charCodeAt(i)-64); return n; }
function parseXLSXRowXML(rowXml, sharedStrings){
  const cells = {};
  let maxc = 0;
  XLSX_CELL_RE.lastIndex = 0;
  let m;
  while ((m = XLSX_CELL_RE.exec(rowXml))){
    const col = m[1], attrs = m[2], inner = m[3];
    const c = xlsxColNum(col);
    if (c > maxc) maxc = c;
    if (!inner){ cells[c] = ''; continue; }
    const tMatch = attrs.match(/\bt="([a-zA-Z]+)"/);
    const t = tMatch ? tMatch[1] : 'n';
    let val = '';
    if (t === 'inlineStr'){
      const tm = inner.match(/<t[^>]*>([\s\S]*?)<\/t>/);
      if (tm) val = tm[1].replace(/<!\[CDATA\[([\s\S]*?)\]\]>/,'$1');
    } else {
      const vm = inner.match(/<v>([\s\S]*?)<\/v>/);
      if (vm){
        val = vm[1];
        if (t === 's' && sharedStrings) val = sharedStrings[Number(val)] || '';
      }
    }
    cells[c] = val;
  }
  const row = new Array(maxc);
  for (let i=1;i<=maxc;i++) row[i-1] = cells[i] !== undefined ? cells[i] : '';
  return row;
}

class XLSXRowBuffer{
  constructor(sharedStrings, onRow){ this.buf=''; this.sharedStrings=sharedStrings; this.onRow=onRow; }
  push(text){
    this.buf += text;
    while (true){
      const start = this.buf.indexOf('<row');
      if (start === -1){
        if (this.buf.length > 20_000_000) throw new Error('Linha da planilha excepcionalmente grande — estrutura do arquivo pode estar corrompida.');
        break;
      }
      const end = this.buf.indexOf('</row>', start);
      if (end === -1){
        if (this.buf.length - start > 20_000_000) throw new Error('Linha da planilha excepcionalmente grande — estrutura do arquivo pode estar corrompida.');
        if (start > 0) this.buf = this.buf.slice(start); // descarta o que não é linha
        break;
      }
      const rowXml = this.buf.slice(start, end+6);
      this.onRow(parseXLSXRowXML(rowXml, this.sharedStrings));
      this.buf = this.buf.slice(end+6);
    }
  }
}

// streamXLSXRows(): orquestra todo o processo acima. onHeader recebe a
// primeira linha; onRow recebe cada linha seguinte; onProgress(0..1).
async function streamXLSXRows(file, onHeader, onRow, onProgress){
  const entries = await zipLocateEntries(file);
  const sheetPath = await resolveFirstSheetPath(file, entries);
  const sheetEntry = entries.get(sheetPath);
  if (!sheetEntry) throw new Error(`Planilha "${sheetPath}" não encontrada dentro do arquivo .xlsx.`);

  let sharedStrings = null;
  if (entries.has('xl/sharedStrings.xml')){
    const ssXml = await zipReadEntryText(file, entries, 'xl/sharedStrings.xml');
    if (ssXml) sharedStrings = parseSharedStringsXML(ssXml);
  }

  const dataStart = await zipEntryDataOffset(file, sheetEntry.localOffset);
  const rawSlice = file.slice(dataStart, dataStart + sheetEntry.compSize);
  const byteStream = sheetEntry.method === 0 ? rawSlice.stream() : rawSlice.stream().pipeThrough(new DecompressionStream('deflate-raw'));
  const reader = byteStream.getReader();
  const decoder = new TextDecoder('utf-8');

  let headerSeen = false, rowCount = 0, bytesRead = 0;
  const rowBuffer = new XLSXRowBuffer(sharedStrings, (row) => {
    if (!headerSeen){ headerSeen = true; onHeader(row); return; }
    rowCount++;
    onRow(row);
  });

  while (true){
    const { done, value } = await reader.read();
    if (done) break;
    bytesRead += value.length;
    rowBuffer.push(decoder.decode(value, { stream:true }));
    if (rowCount % 20000 < 400) { onProgress && onProgress(Math.min(0.99, bytesRead / sheetEntry.compSize)); await yieldToUI(); }
  }
  rowBuffer.push(decoder.decode());
  onProgress && onProgress(1);
  return rowCount;
}

async function streamTrilhaXLSX(file, store, progressCb){
  let idx = null, missing = [];
  const unmatchedDealers = new Set();
  await streamXLSXRows(file,
    (headers) => { const r = normalizeColumns(headers, CONFIG_COLUMN_MAP.trilha); idx = r.idx; missing = r.missing; },
    (row) => { if (idx) pushTrilhaRow(idx, row, store, unmatchedDealers); },
    progressCb
  );
  if (missing.length) console.warn('[Trilha/XLSX-stream] Colunas não encontradas:', missing);
  return { missing, unmatchedDealers };
}
async function streamMatriculaXLSX(file, store, progressCb){
  let idx = null, missing = [];
  const unmatchedDealers = new Set();
  await streamXLSXRows(file,
    (headers) => { const r = normalizeColumns(headers, CONFIG_COLUMN_MAP.matricula); idx = r.idx; missing = r.missing; },
    (row) => { if (idx) pushMatriculaRow(idx, row, store, unmatchedDealers); },
    progressCb
  );
  if (missing.length) console.warn('[Matrícula/XLSX-stream] Colunas não encontradas:', missing);
  return { missing, unmatchedDealers };
}

// readExcelFile(): lê um File via SheetJS e devolve {headers, rows} (AOA).
// Este é o caminho de RESERVA (fallback), usado apenas quando o navegador
// não suporta DecompressionStream ou quando o leitor em fluxo falha por
// alguma estrutura de arquivo fora do padrão. Para arquivos muito grandes,
// esse caminho precisa alocar o arquivo inteiro na memória e pode falhar
// (erro tipicamente relacionado a "array buffer"/"invalid array length").
function readExcelFile(file){
  return new Promise((resolve, reject)=>{
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Falha ao ler o arquivo do disco (permissão ou arquivo corrompido).'));
    reader.onload = (e) => {
      try{
        const data = new Uint8Array(e.target.result);
        // dense:true evita o modelo de célula "esparso" (um objeto por
        // endereço A1), que praticamente dobra o consumo de memória em
        // arquivos grandes. Lemos ws['!data'] diretamente (array de arrays)
        // em vez de chamar sheet_to_json, que criaria uma SEGUNDA cópia
        // completa da planilha na memória.
        const wb = XLSX.read(data, { type:'array', cellDates:false, raw:true, dense:true });
        const sheetName = wb.SheetNames[0];
        const ws = wb.Sheets[sheetName];
        const dense = ws['!data'];
        let headers, rows;
        if (dense){
          if (!dense.length) return reject(new Error('Planilha vazia.'));
          const toRow = (r) => { const out=[]; const cells=r||[]; for (let c=0;c<cells.length;c++){ out[c] = cells[c] ? cells[c].v : ''; } return out; };
          headers = toRow(dense[0]).map(h => String(h||'').trim());
          rows = new Array(dense.length-1);
          for (let i=1;i<dense.length;i++) rows[i-1] = toRow(dense[i]);
        } else {
          // fallback (modo esparso, caso a versão da lib não suporte dense)
          const aoa = XLSX.utils.sheet_to_json(ws, { header:1, raw:true, defval:'' });
          if (!aoa.length) return reject(new Error('Planilha vazia.'));
          headers = aoa[0].map(h => String(h||'').trim());
          rows = aoa.slice(1);
        }
        resolve({ headers, rows });
      }catch(err){
        reject(translateParseError(err, file));
      }
    };
    reader.onerror = () => reject(new Error('Falha ao ler o arquivo.'));
    try{
      reader.readAsArrayBuffer(file);
    }catch(err){
      reject(translateParseError(err, file));
    }
  });
}

// translateParseError(): converte erros técnicos (ex.: estouro de memória ao
// alocar array buffer) em mensagens acionáveis para o usuário.
function translateParseError(err, file){
  const msg = String(err && err.message ? err.message : err);
  const sizeMB = file ? (file.size/1024/1024).toFixed(0) : '?';
  if (/array buffer|invalid array length|invalid typed array|out of memory|allocation failed|maximum call stack|invalid string length|err_string_too_long|string longer than/i.test(msg)){
    return new Error(
      `O arquivo (${sizeMB}MB) é grande demais para ser carregado inteiramente na memória do navegador nesta ` +
      `máquina/dispositivo. Sugestões: (1) exporte o relatório em formato .csv no LMS — este dashboard lê CSV ` +
      `em fluxo, sem esse limite; (2) divida o relatório em partes menores (ex.: por período/KI) e envie uma de cada vez ` +
      `— dados de uploads anteriores do mesmo tipo são somados; (3) use um computador com mais memória RAM, feche ` +
      `outras abas do navegador e tente novamente.`
    );
  }
  return err instanceof Error ? err : new Error(msg);
}

// readCSVFile(): lê um .csv em FLUXO (streaming) usando PapaParse, chamando
// onRow(rowArray) para cada linha, sem nunca materializar o arquivo inteiro
// em memória. É o caminho recomendado para arquivos muito grandes.
function readCSVFile(file, onHeader, onRow, onProgress){
  return new Promise((resolve, reject)=>{
    if (typeof Papa === 'undefined'){
      reject(new Error('Biblioteca de leitura de CSV (PapaParse) não carregou. Verifique sua conexão com a internet.'));
      return;
    }
    let headerSeen = false, rowCount = 0;
    Papa.parse(file, {
      worker: true,
      skipEmptyLines: true,
      chunkSize: 1024 * 1024 * 4,
      step: (results) => {
        const row = results.data;
        if (!headerSeen){ headerSeen = true; onHeader(row.map(h=>String(h||'').trim())); return; }
        onRow(row);
        rowCount++;
        if (rowCount % 20000 === 0) onProgress && onProgress(rowCount);
      },
      complete: () => resolve(rowCount),
      error: (err) => reject(translateParseError(err, file))
    });
  });
}

// normalizeColumns(): resolve, para um dado header real, o índice de cada
// campo lógico definido em CONFIG_COLUMN_MAP[<tipo>].
function normalizeColumns(headers, mapDef){
  const idx = {};
  const missing = [];
  for (const field in mapDef){
    const aliases = mapDef[field];
    let found = -1;
    for (const alias of aliases){
      const pos = headers.findIndex(h => h.localeCompare(alias, 'pt-BR', {sensitivity:'base'}) === 0);
      if (pos !== -1){ found = pos; break; }
    }
    idx[field] = found;
    if (found === -1) missing.push(field);
  }
  return { idx, missing };
}

// Excel serial date -> epoch ms (sistema de datas 1900). Retorna null se inválido.
function excelSerialToDate(v){
  if (v === '' || v === null || v === undefined) return null;
  const n = Number(v);
  if (!isFinite(n) || n <= 0) return null;
  const ms = Math.round((n - 25569) * 86400 * 1000);
  return ms;
}

// parseFlexibleDate(): aceita tanto serial numérico do Excel (.xlsx) quanto
// texto (comum em .csv exportado), nos formatos dd/mm/aaaa ou aaaa-mm-dd,
// com ou sem hora.
function parseFlexibleDate(v){
  if (v === '' || v === null || v === undefined) return null;
  if (typeof v === 'number') return excelSerialToDate(v);
  const s = String(v).trim();
  if (!s) return null;
  if (/^\d+(\.\d+)?$/.test(s)) return excelSerialToDate(Number(s));
  let m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
  if (m) return Date.UTC(+m[3], +m[2]-1, +m[1], +(m[4]||0), +(m[5]||0), +(m[6]||0));
  m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
  if (m) return Date.UTC(+m[1], +m[2]-1, +m[3], +(m[4]||0), +(m[5]||0), +(m[6]||0));
  return null;
}

function normStr(v){ return String(v==null?'':v).trim(); }
function normUpper(v){ return normStr(v).toUpperCase(); }
function stripAccents(s){ return normStr(s).normalize('NFD').replace(/[\u0300-\u036f]/g,''); }
function isPresencial(v){ return stripAccents(v).toUpperCase().indexOf('PRESENCIAL') !== -1; }
// isPresencialOuBlended(): usado pelo filtro MASTER. Cobre variações comuns
// de rotulagem ("Presencial", "Blended", "Blended Learning", "Semipresencial"...).
// Ajuste esta lista se sua base usar outros rótulos para os mesmos conceitos.
function isPresencialOuBlended(v){
  const s = stripAccents(v).toUpperCase();
  return s.indexOf('PRESENCIAL') !== -1 || s.indexOf('BLEND') !== -1;
}
function isSim(v){ return stripAccents(v).toUpperCase() === 'SIM'; }
function isAprovado(v){ const s = stripAccents(v).toUpperCase(); return s==='APROVADO' || s==='SIM' || s==='CONCLUIDO'; }
function isInativo(v){ return stripAccents(v).toUpperCase().indexOf('INATIVO') !== -1; }

// dateToKI(): Honda fiscal year (KI), início 01/04, fim 31/03.
function dateToKI(ms){
  if (ms==null) return null;
  const d = new Date(ms);
  const y = d.getUTCFullYear(), m = d.getUTCMonth();
  const kiStartYear = m >= 3 ? y : y - 1; // abril=index 3
  return CONFIG.kiAnchorNumber + (kiStartYear - CONFIG.kiAnchorYear);
}
function kiRange(kiNumber){
  const startYear = CONFIG.kiAnchorYear + (kiNumber - CONFIG.kiAnchorNumber);
  const start = Date.UTC(startYear, 3, 1);
  const end = Date.UTC(startYear+1, 2, 31, 23, 59, 59);
  return { start, end };
}
function currentKI(){ return dateToKI(Date.now()); }

// dealerCodeFromHierarquia(): extrai o código da concessionária de uma
// string "HSA - Honda South America/Brazil/4W/S8/1018523-CAIUAS".
function dealerCodeFromHierarquia(h){
  const m = normStr(h).match(/\/(\d{5,8})-/);
  return m ? m[1] : '';
}

/* ---- Interning de strings ----
   Os relatórios repetem exaustivamente os mesmos valores (nome do curso,
   cargo, modalidade, código de concessionária...) em milhões de linhas. Sem
   interning, cada ocorrência vira uma alocação de string independente na
   memória do V8; com interning, ocorrências idênticas compartilham a MESMA
   string, reduzindo o consumo de memória em arquivos muito grandes. */
const __internPool = new Map();
function intern(s){
  if (s === '') return '';
  const hit = __internPool.get(s);
  if (hit !== undefined) return hit;
  __internPool.set(s, s);
  return s;
}

/* ---- Armazenamento colunar ---- */
function newTrilhaStore(){
  return { dealer:[], cargo:[], curso:[], aprovado:[], peso:[], modalidade:[], dataIni:[], dataFim:[], cpf:[], usuario:[], n:0 };
}
function newMatriculaStore(){
  return { dealer:[], cargo:[], curso:[], modalidade:[], turma:[], dataMatricula:[], dataInicio:[], dataConclusao:[],
           statusMatricula:[], situacaoAluno:[], situacaoUsuario:[], cpf:[], genero:[], usuario:[], n:0 };
}
// truncateStore(): remove linhas além de n (usado para desfazer uma
// tentativa de leitura em fluxo que falhou no meio, antes de cair para o
// método alternativo — evita duplicar linhas já inseridas com sucesso).
function truncateStore(store, n){
  for (const key in store){
    if (Array.isArray(store[key])) store[key].length = n;
  }
  store.n = n;
}

// pushTrilhaRow() / pushMatriculaRow(): transformam UMA linha crua (array)
// em registros no armazenamento colunar. Compartilhadas pelos dois caminhos
// de leitura (.xlsx em memória e .csv em fluxo) para manter a mesma regra
// de negócio nos dois casos.
// parsePeso(): converte o valor de "Peso do Recurso" para número. Células
// em branco ou não numéricas caem para peso 1 (equivalente a não ponderar
// aquele item específico), o que também cobre o caso do arquivo não ter
// essa coluna — o IT nesse caso volta a se comportar como contagem simples.
function parsePeso(v){
  if (v === '' || v === null || v === undefined) return 1;
  const n = Number(v);
  return isFinite(n) ? n : 1;
}

function pushTrilhaRow(idx, r, store, unmatchedDealers){
  const codUnidade = idx.codUnidade!==-1 ? normStr(r[idx.codUnidade]) : '';
  if (!codUnidade) return;
  if (!STATE.dealersByCode.has(codUnidade)) unmatchedDealers.add(codUnidade);
  const modalidade = idx.modalidade!==-1 ? normStr(r[idx.modalidade]) : '';
  store.dealer.push(intern(codUnidade));
  store.cargo.push(intern(idx.cargo!==-1 ? normStr(r[idx.cargo]) : ''));
  store.curso.push(intern(idx.recurso!==-1 ? normStr(r[idx.recurso]) : ''));
  store.aprovado.push(idx.aprovacao!==-1 && isSim(r[idx.aprovacao]) ? 1 : 0);
  store.peso.push(idx.pesoRecurso!==-1 ? parsePeso(r[idx.pesoRecurso]) : 1);
  store.modalidade.push(intern(modalidade));
  store.dataIni.push(idx.dataInicioCarencia!==-1 ? parseFlexibleDate(r[idx.dataInicioCarencia]) : null);
  store.dataFim.push(idx.dataFimCarencia!==-1 ? parseFlexibleDate(r[idx.dataFimCarencia]) : null);
  store.cpf.push(idx.cpf!==-1 ? normStr(r[idx.cpf]) : '');
  store.usuario.push(idx.usuario!==-1 ? normStr(r[idx.usuario]) : '');
  store.n++;
}

function pushMatriculaRow(idx, r, store, unmatchedDealers){
  let dealerCode = idx.dealerCode!==-1 ? normStr(r[idx.dealerCode]) : '';
  if (!dealerCode && idx.hierarquia!==-1) dealerCode = dealerCodeFromHierarquia(r[idx.hierarquia]);
  if (!dealerCode) return;
  if (!STATE.dealersByCode.has(dealerCode)) unmatchedDealers.add(dealerCode);
  const modalidade = idx.modalidade!==-1 ? normStr(r[idx.modalidade]) : '';
  store.dealer.push(intern(dealerCode));
  store.cargo.push(intern(idx.cargo!==-1 ? normStr(r[idx.cargo]) : ''));
  store.curso.push(intern(idx.curso!==-1 ? normStr(r[idx.curso]) : ''));
  store.modalidade.push(intern(modalidade));
  store.turma.push(intern(idx.turma!==-1 ? normStr(r[idx.turma]) : ''));
  store.dataMatricula.push(idx.dataMatricula!==-1 ? parseFlexibleDate(r[idx.dataMatricula]) : null);
  store.dataInicio.push(idx.dataInicio!==-1 ? parseFlexibleDate(r[idx.dataInicio]) : null);
  store.dataConclusao.push(idx.dataConclusao!==-1 ? parseFlexibleDate(r[idx.dataConclusao]) : null);
  store.statusMatricula.push(intern(idx.statusMatricula!==-1 ? normStr(r[idx.statusMatricula]) : ''));
  store.situacaoAluno.push(intern(idx.situacaoAluno!==-1 ? normStr(r[idx.situacaoAluno]) : ''));
  store.situacaoUsuario.push(intern(idx.situacaoUsuario!==-1 ? normStr(r[idx.situacaoUsuario]) : ''));
  store.cpf.push(idx.cpf!==-1 ? normStr(r[idx.cpf]) : '');
  store.genero.push(intern(idx.genero!==-1 ? normStr(r[idx.genero]) : ''));
  store.usuario.push(idx.usuario!==-1 ? normStr(r[idx.usuario]) : '');
  store.n++;
}

// prepareTrilhaRows()/prepareMatriculaRows(): caminho .xlsx — dados já
// totalmente carregados em memória como AOA (array de arrays).
async function prepareTrilhaRows(headers, rows, store, progressCb){
  const { idx, missing } = normalizeColumns(headers, CONFIG_COLUMN_MAP.trilha);
  if (missing.length) console.warn('[Trilha] Colunas não encontradas, ajuste CONFIG_COLUMN_MAP.trilha:', missing);
  const total = rows.length, BATCH = 20000;
  const unmatchedDealers = new Set();
  for (let i=0;i<total;i++){
    pushTrilhaRow(idx, rows[i], store, unmatchedDealers);
    if (i % BATCH === 0){ progressCb && progressCb(i/total); await yieldToUI(); }
  }
  return { missing, unmatchedDealers };
}

async function prepareMatriculaRows(headers, rows, store, progressCb){
  const { idx, missing } = normalizeColumns(headers, CONFIG_COLUMN_MAP.matricula);
  if (missing.length) console.warn('[Matrícula] Colunas não encontradas, ajuste CONFIG_COLUMN_MAP.matricula:', missing);
  const total = rows.length, BATCH = 20000;
  const unmatchedDealers = new Set();
  for (let i=0;i<total;i++){
    pushMatriculaRow(idx, rows[i], store, unmatchedDealers);
    if (i % BATCH === 0){ progressCb && progressCb(i/total); await yieldToUI(); }
  }
  return { missing, unmatchedDealers };
}

// streamTrilhaCSV()/streamMatriculaCSV(): caminho .csv — leitura em fluxo,
// linha a linha, sem materializar o arquivo inteiro em memória. Recomendado
// para arquivos muito grandes (dezenas/centenas de MB).
async function streamTrilhaCSV(file, store, progressCb){
  let idx = null, missing = [];
  const unmatchedDealers = new Set();
  await readCSVFile(file,
    (headers) => { const r = normalizeColumns(headers, CONFIG_COLUMN_MAP.trilha); idx = r.idx; missing = r.missing; },
    (row) => { if (idx) pushTrilhaRow(idx, row, store, unmatchedDealers); },
    (count) => progressCb && progressCb(count)
  );
  if (missing.length) console.warn('[Trilha/CSV] Colunas não encontradas, ajuste CONFIG_COLUMN_MAP.trilha:', missing);
  return { missing, unmatchedDealers };
}

async function streamMatriculaCSV(file, store, progressCb){
  let idx = null, missing = [];
  const unmatchedDealers = new Set();
  await readCSVFile(file,
    (headers) => { const r = normalizeColumns(headers, CONFIG_COLUMN_MAP.matricula); idx = r.idx; missing = r.missing; },
    (row) => { if (idx) pushMatriculaRow(idx, row, store, unmatchedDealers); },
    (count) => progressCb && progressCb(count)
  );
  if (missing.length) console.warn('[Matrícula/CSV] Colunas não encontradas, ajuste CONFIG_COLUMN_MAP.matricula:', missing);
  return { missing, unmatchedDealers };
}

/* ========================================================================
   5) Upload handlers
======================================================================== */
const LARGE_FILE_WARN_MB = 60;
const MOBILE_FILE_WARN_MB = 25;
function isLikelyMobile(){
  return /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent || '');
}
function isLikelyLowMemory(){
  // navigator.deviceMemory (Chrome/Android) informa RAM aproximada em GB.
  return typeof navigator.deviceMemory === 'number' && navigator.deviceMemory <= 4;
}
function effectiveWarnThresholdMB(){
  return (isLikelyMobile() || isLikelyLowMemory()) ? MOBILE_FILE_WARN_MB : LARGE_FILE_WARN_MB;
}

async function handleTrilhaUpload(file, label){
  if (!file) return;
  if (!/\.(xlsx|xls|csv)$/i.test(file.name)){
    toast('Arquivo inválido: envie um .xlsx, .xls ou .csv', 'error');
    return;
  }
  const isCSV = /\.csv$/i.test(file.name);
  const isXLS = /\.xls$/i.test(file.name); // legado, não é ZIP — sempre via SheetJS
  const sizeMB = file.size/1024/1024;
  const cardId = label === '2W' ? 'cardTrilha2W' : 'cardTrilha4W';
  const statusId = label === '2W' ? 'statusTrilha2W' : 'statusTrilha4W';
  const card = document.getElementById(cardId), statusEl = document.getElementById(statusId);
  card.classList.remove('is-error');
  showLoader(`Lendo ${label} — Acompanhamento IT (arquivos grandes podem levar alguns minutos)...`);
  try{
    if (!STATE.trilha) STATE.trilha = newTrilhaStore();
    let missing, unmatchedDealers, rowCount;
    if (isCSV){
      const res = await streamTrilhaCSV(file, STATE.trilha, (n)=>{ document.getElementById('loaderText').textContent = `Processando ${label} (CSV): ${n.toLocaleString('pt-BR')} linhas...`; });
      missing = res.missing; unmatchedDealers = res.unmatchedDealers; rowCount = STATE.trilha.n;
    } else if (!isXLS && supportsStreamingXLSX()){
      const startN = STATE.trilha.n;
      try{
        document.getElementById('loaderText').textContent = `Lendo ${label} em fluxo (sem carregar o arquivo inteiro na memória)...`;
        const res = await streamTrilhaXLSX(file, STATE.trilha, (p)=>{ document.getElementById('loaderText').textContent = `Processando ${label}: ${(p*100).toFixed(0)}%`; });
        missing = res.missing; unmatchedDealers = res.unmatchedDealers; rowCount = STATE.trilha.n;
      }catch(streamErr){
        console.warn('Leitura em fluxo falhou, tentando modo tradicional (memória inteira):', streamErr);
        toast(`Leitura em fluxo de ${label} falhou (${streamErr.message}). Tentando método alternativo...`, 'warn');
        truncateStore(STATE.trilha, startN);
        const { headers, rows } = await readExcelFile(file);
        showLoader(`Processando ${rows.length.toLocaleString('pt-BR')} linhas de ${label}...`);
        const res = await prepareTrilhaRows(headers, rows, STATE.trilha, (p)=>{
          document.getElementById('loaderText').textContent = `Processando ${label}: ${(p*100).toFixed(0)}%`;
        });
        missing = res.missing; unmatchedDealers = res.unmatchedDealers; rowCount = rows.length;
      }
    } else {
      const warnThreshold = effectiveWarnThresholdMB();
      if (sizeMB > warnThreshold){
        const mobileNote = isLikelyMobile() ? ' Em celulares, arquivos grandes têm chance real de falhar por memória — CSV é a opção mais confiável aqui.' : '';
        toast(`Arquivo de ${sizeMB.toFixed(0)}MB detectado.${mobileNote} Este navegador não suporta leitura em fluxo${isXLS?' para .xls':''}; se falhar, exporte como .csv.`, 'warn');
      }
      const { headers, rows } = await readExcelFile(file);
      showLoader(`Processando ${rows.length.toLocaleString('pt-BR')} linhas de ${label}...`);
      const res = await prepareTrilhaRows(headers, rows, STATE.trilha, (p)=>{
        document.getElementById('loaderText').textContent = `Processando ${label}: ${(p*100).toFixed(0)}%`;
      });
      missing = res.missing; unmatchedDealers = res.unmatchedDealers; rowCount = rows.length;
    }
    STATE.filesLoaded[label==='2W' ? 'trilha2W' : 'trilha4W'] = true;
    card.classList.add('is-loaded');
    statusEl.textContent = `${rowCount.toLocaleString('pt-BR')} linhas · ${file.name}`;
    if (missing.length) toast(`Aviso (${label}): colunas não localizadas: ${missing.join(', ')} — ajuste CONFIG_COLUMN_MAP.trilha`, 'warn');
    else toast(`Arquivo ${label} carregado com sucesso.`, 'success');
    if (unmatchedDealers.size) toast(`${unmatchedDealers.size} código(s) de concessionária do arquivo ${label} não constam na base BD_CONCESSIONARIAS e foram ignorados nos indicadores.`, 'warn');
    rebuildFilterOptions();
    renderActiveTab();
  }catch(err){
    console.error(err);
    card.classList.add('is-error');
    statusEl.textContent = 'Erro ao processar arquivo';
    toast(`Erro ao processar ${label}: ${err.message}`, 'error');
  }finally{
    hideLoader();
  }
}

async function handleMatriculaUpload(file){
  if (!file) return;
  if (!/\.(xlsx|xls|csv)$/i.test(file.name)){
    toast('Arquivo inválido: envie um .xlsx, .xls ou .csv', 'error');
    return;
  }
  const isCSV = /\.csv$/i.test(file.name);
  const isXLS = /\.xls$/i.test(file.name);
  const sizeMB = file.size/1024/1024;
  const card = document.getElementById('cardMatriculas'), statusEl = document.getElementById('statusMatriculas');
  card.classList.remove('is-error');
  showLoader('Lendo Relatório Geral de Matrícula...');
  try{
    STATE.matricula = newMatriculaStore();
    let missing, unmatchedDealers;
    if (isCSV){
      const res = await streamMatriculaCSV(file, STATE.matricula, (n)=>{ document.getElementById('loaderText').textContent = `Processando matrículas (CSV): ${n.toLocaleString('pt-BR')} linhas...`; });
      missing = res.missing; unmatchedDealers = res.unmatchedDealers;
    } else if (!isXLS && supportsStreamingXLSX()){
      try{
        document.getElementById('loaderText').textContent = 'Lendo matrículas em fluxo (sem carregar o arquivo inteiro na memória)...';
        const res = await streamMatriculaXLSX(file, STATE.matricula, (p)=>{ document.getElementById('loaderText').textContent = `Processando matrículas: ${(p*100).toFixed(0)}%`; });
        missing = res.missing; unmatchedDealers = res.unmatchedDealers;
      }catch(streamErr){
        console.warn('Leitura em fluxo falhou, tentando modo tradicional (memória inteira):', streamErr);
        toast(`Leitura em fluxo falhou (${streamErr.message}). Tentando método alternativo...`, 'warn');
        STATE.matricula = newMatriculaStore();
        const { headers, rows } = await readExcelFile(file);
        showLoader(`Processando ${rows.length.toLocaleString('pt-BR')} linhas de matrícula...`);
        const res = await prepareMatriculaRows(headers, rows, STATE.matricula, (p)=>{
          document.getElementById('loaderText').textContent = `Processando matrículas: ${(p*100).toFixed(0)}%`;
        });
        missing = res.missing; unmatchedDealers = res.unmatchedDealers;
      }
    } else {
      const warnThreshold = effectiveWarnThresholdMB();
      if (sizeMB > warnThreshold){
        const mobileNote = isLikelyMobile() ? ' Em celulares, arquivos grandes têm chance real de falhar por memória — CSV é a opção mais confiável aqui.' : '';
        toast(`Arquivo de ${sizeMB.toFixed(0)}MB detectado.${mobileNote} Este navegador não suporta leitura em fluxo${isXLS?' para .xls':''}; se falhar, exporte como .csv.`, 'warn');
      }
      const { headers, rows } = await readExcelFile(file);
      showLoader(`Processando ${rows.length.toLocaleString('pt-BR')} linhas de matrícula...`);
      const res = await prepareMatriculaRows(headers, rows, STATE.matricula, (p)=>{
        document.getElementById('loaderText').textContent = `Processando matrículas: ${(p*100).toFixed(0)}%`;
      });
      missing = res.missing; unmatchedDealers = res.unmatchedDealers;
    }
    STATE.filesLoaded.matriculas = true;
    card.classList.add('is-loaded');
    statusEl.textContent = `${STATE.matricula.n.toLocaleString('pt-BR')} matrículas (todas as modalidades) · ${file.name}`;
    if (missing.length) toast(`Aviso (Matrícula): colunas não localizadas: ${missing.join(', ')} — ajuste CONFIG_COLUMN_MAP.matricula`, 'warn');
    else toast('Relatório de matrícula carregado com sucesso.', 'success');
    if (unmatchedDealers.size) toast(`${unmatchedDealers.size} código(s) de concessionária do relatório de matrícula não constam na base BD_CONCESSIONARIAS e foram ignorados nos indicadores.`, 'warn');
    rebuildFilterOptions();
    renderActiveTab();
  }catch(err){
    console.error(err);
    card.classList.add('is-error');
    statusEl.textContent = 'Erro ao processar arquivo';
    toast(`Erro ao processar matrículas: ${err.message}`, 'error');
  }finally{
    hideLoader();
  }
}

/* ========================================================================
   6) Filtros globais
======================================================================== */
function dealerMeta(code){
  return STATE.dealersByCode.get(code) || null;
}

// applyGlobalFilters(): devolve os índices (array de int) do dataset colunar
// informado que atendem aos filtros ativos + segmento + período KI/datas.
function applyGlobalFilters(store, kind){
  const idxs = [];
  if (!store) return idxs;
  const f = STATE.filters;
  const seg = STATE.segment;
  const hasDealerFilter = f.dealers.size > 0;
  let kiWindow = null;
  if (f.ki) kiWindow = kiRange(Number(f.ki));
  const custIni = f.dataInicio ? new Date(f.dataInicio+'T00:00:00').getTime() : null;
  const custFim = f.dataFim ? new Date(f.dataFim+'T23:59:59').getTime() : null;

  for (let i=0;i<store.n;i++){
    const code = store.dealer[i];
    const meta = dealerMeta(code);
    if (!meta) continue;                 // concessionária não reconhecida na base BD
    if (meta.segmento !== seg) continue;
    if (f.masterPresencialBlended && !isPresencialOuBlended(store.modalidade[i])) continue;
    if (f.uf && meta.uf !== f.uf) continue;
    if (f.regiao && meta.regiao !== f.regiao) continue;
    if (hasDealerFilter && !f.dealers.has(code)) continue;
    if (f.cargo && store.cargo[i] !== f.cargo) continue;

    if (kind === 'trilha'){
      if (f.curso && store.curso[i] !== f.curso) continue;
      const dref = store.dataFim[i] != null ? store.dataFim[i] : store.dataIni[i];
      if (kiWindow && dref != null && (dref < kiWindow.start || dref > kiWindow.end)) continue;
      if ((custIni || custFim) && dref != null){
        if (custIni && dref < custIni) continue;
        if (custFim && dref > custFim) continue;
      }
    } else {
      if (f.curso && store.curso[i] !== f.curso) continue;
      const dref = store.dataConclusao[i] != null ? store.dataConclusao[i] : store.dataInicio[i];
      if (kiWindow && dref != null && (dref < kiWindow.start || dref > kiWindow.end)) continue;
      if ((custIni || custFim) && dref != null){
        if (custIni && dref < custIni) continue;
        if (custFim && dref > custFim) continue;
      }
    }
    idxs.push(i);
  }
  return idxs;
}

function rebuildFilterOptions(){
  // UF (a partir da base de concessionárias do segmento ativo)
  const ufSel = document.getElementById('fUF');
  const ufsInSeg = new Set();
  STATE.dealersByCode.forEach(d => { if (d.segmento===STATE.segment) ufsInSeg.add(d.uf); });
  const curUF = ufSel.value;
  ufSel.innerHTML = '<option value="">Todas</option>' + [...ufsInSeg].sort().map(u=>`<option value="${u}">${u}</option>`).join('');
  ufSel.value = ufsInSeg.has(curUF) ? curUF : '';

  // Curso / Cargo dinâmicos a partir dos dados carregados (respeitando o
  // filtro MASTER de modalidade, para não listar cursos/cargos que só
  // existem em modalidades ocultas no momento)
  const masterOn = STATE.filters.masterPresencialBlended;
  const cursoSet = new Set(), cargoSet = new Set();
  if (STATE.trilha) for (let i=0;i<STATE.trilha.n;i++){
    if (masterOn && !isPresencialOuBlended(STATE.trilha.modalidade[i])) continue;
    if(STATE.trilha.curso[i]) cursoSet.add(STATE.trilha.curso[i]); if(STATE.trilha.cargo[i]) cargoSet.add(STATE.trilha.cargo[i]);
  }
  if (STATE.matricula) for (let i=0;i<STATE.matricula.n;i++){
    if (masterOn && !isPresencialOuBlended(STATE.matricula.modalidade[i])) continue;
    if(STATE.matricula.curso[i]) cursoSet.add(STATE.matricula.curso[i]); if(STATE.matricula.cargo[i]) cargoSet.add(STATE.matricula.cargo[i]);
  }
  const cursoSel = document.getElementById('fCurso'); const curCurso = cursoSel.value;
  cursoSel.innerHTML = '<option value="">Todos</option>' + [...cursoSet].sort().map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
  cursoSel.value = cursoSet.has(curCurso) ? curCurso : '';
  const cargoSel = document.getElementById('fCargo'); const curCargo = cargoSel.value;
  cargoSel.innerHTML = '<option value="">Todos</option>' + [...cargoSet].sort().map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
  cargoSel.value = cargoSet.has(curCargo) ? curCargo : '';

  // KI dinâmico (últimos e próximos períodos)
  const kiSel = document.getElementById('fKI'); const curKI = kiSel.value;
  const cur = currentKI();
  let opts = '<option value="">Todos</option>';
  for (let k=cur-4;k<=cur+1;k++){ const r = kiRange(k); opts += `<option value="${k}">${k}KI (${fmtDateShort(r.start)}–${fmtDateShort(r.end)})</option>`; }
  kiSel.innerHTML = opts;
  kiSel.value = curKI;

  updateFilterCount();
}

function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
// dealerLabel(): nome da concessionária + código, para exibir junto em
// listas/tabelas/rankings (ex.: "CANDEMIL (1010077)").
function dealerLabel(meta){ return meta ? `${meta.nome} (${meta.codigo})` : ''; }
function dealerLabelByCode(code){ return dealerLabel(dealerMeta(code)) || code; }
function fmtDateShort(ms){ if(ms==null) return '—'; const d = new Date(ms); return d.toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit',year:'2-digit'}); }
function fmtDate(ms){ if(ms==null) return '—'; return new Date(ms).toLocaleDateString('pt-BR'); }
function fmtPct(n){ return (isFinite(n)? (n*100).toFixed(1) : '0.0') + '%'; }

function updateFilterCount(){
  const dealersInSeg = [...STATE.dealersByCode.values()].filter(d=>d.segmento===STATE.segment).length;
  document.getElementById('filterCount').textContent = `${dealersInSeg.toLocaleString('pt-BR')} concessionárias na base (${STATE.segment})`;
}

/* ---- Multiselect de concessionárias (pesquisável) ---- */
function initDealerMultiselect(){
  const input = document.getElementById('dealerMsInput');
  const dropdown = document.getElementById('dealerMsDropdown');
  const wrap = document.getElementById('dealerMsInputWrap');

  function renderChips(){
    wrap.querySelectorAll('.ms-chip').forEach(c=>c.remove());
    STATE.filters.dealers.forEach(code=>{
      const meta = dealerMeta(code);
      const chip = document.createElement('span');
      chip.className = 'ms-chip';
      chip.innerHTML = `${escapeHtml(meta ? dealerLabel(meta) : code)} <button type="button" aria-label="remover">×</button>`;
      chip.querySelector('button').onclick = ()=>{ STATE.filters.dealers.delete(code); renderChips(); renderActiveTab(); };
      wrap.insertBefore(chip, input);
    });
  }
  function search(term){
    term = stripAccents(term).toUpperCase();
    const results = [];
    STATE.dealersByCode.forEach(d=>{
      if (d.segmento !== STATE.segment) return;
      if (STATE.filters.dealers.has(d.codigo)) return;
      if (!term || stripAccents(d.nome).toUpperCase().includes(term) || d.codigo.includes(term) || stripAccents(d.cidade).toUpperCase().includes(term)){
        results.push(d);
      }
    });
    results.sort((a,b)=>a.nome.localeCompare(b.nome));
    return results.slice(0,60);
  }
  function renderDropdown(term){
    const results = search(term);
    if (!results.length){ dropdown.innerHTML = '<div class="ms-empty">Nenhuma concessionária encontrada</div>'; }
    else {
      dropdown.innerHTML = results.map(d=>`<div class="ms-option" data-code="${d.codigo}">${escapeHtml(d.nome)} <small>${d.codigo} · ${escapeHtml(d.cidade)}/${d.uf}</small></div>`).join('');
      dropdown.querySelectorAll('.ms-option').forEach(el=>{
        el.onclick = ()=>{ STATE.filters.dealers.add(el.dataset.code); input.value=''; renderChips(); dropdown.classList.remove('open'); renderActiveTab(); };
      });
    }
    dropdown.classList.add('open');
  }
  input.addEventListener('input', ()=>renderDropdown(input.value));
  input.addEventListener('focus', ()=>renderDropdown(input.value));
  document.addEventListener('click', (e)=>{ if(!document.getElementById('dealerMsBox').contains(e.target)) dropdown.classList.remove('open'); });
  renderChips();
  window.__renderDealerChips = renderChips;
}

/* ========================================================================
   7) Funções de cálculo por aba
======================================================================== */

// calculateIT(): IT = média ponderada por concessionária, usando o peso de
// cada recurso/curso (coluna N, "Peso do Recurso"). Para cada linha
// (usuário × curso): soma-se o peso ao total; se Aprovação = Sim, o mesmo
// peso também soma ao numerador (pesoAprovado). IT = pesoAprovado / pesoTotal.
// Os campos "total"/"aprovados" (contagem simples) são mantidos apenas para
// exibição informativa ("X de Y certificações"), mas o percentual de IT
// exibido em qualquer lugar do dashboard usa SEMPRE pesoAprovado/pesoTotal.
function calculateIT(idxs, store){
  const byDealer = new Map();
  for (const i of idxs){
    const d = store.dealer[i];
    const peso = store.peso[i];
    if (!byDealer.has(d)) byDealer.set(d, {total:0, aprovados:0, pesoTotal:0, pesoAprovado:0});
    const o = byDealer.get(d);
    o.total++; if (store.aprovado[i]) o.aprovados++;
    o.pesoTotal += peso;
    if (store.aprovado[i]) o.pesoAprovado += peso;
  }
  return byDealer; // Map dealer -> {total,aprovados,pesoTotal,pesoAprovado}
}

// calculateITPorFuncao(): mesma lógica de média ponderada, agregada por cargo/função.
function calculateITPorFuncao(idxs, store){
  const byCargo = new Map();
  for (const i of idxs){
    const c = store.cargo[i] || 'Não informado';
    const peso = store.peso[i];
    if (!byCargo.has(c)) byCargo.set(c, {total:0, aprovados:0, pesoTotal:0, pesoAprovado:0});
    const o = byCargo.get(c);
    o.total++; if (store.aprovado[i]) o.aprovados++;
    o.pesoTotal += peso;
    if (store.aprovado[i]) o.pesoAprovado += peso;
  }
  return byCargo;
}

// calculateAbsenceDays(): último treinamento presencial concluído por concessionária (matrícula)
function calculateAbsenceDays(idxs, store){
  const lastByDealer = new Map();
  for (const i of idxs){
    if (!isAprovado(store.situacaoAluno[i]) && stripAccents(store.statusMatricula[i]).toUpperCase()!=='CONCLUIDO') continue;
    const d = store.dataConclusao[i];
    if (d == null) continue;
    const dealer = store.dealer[i];
    if (!lastByDealer.has(dealer) || d > lastByDealer.get(dealer)) lastByDealer.set(dealer, d);
  }
  const now = Date.now();
  const result = [];
  STATE.dealersByCode.forEach(meta=>{
    if (meta.segmento !== STATE.segment) return;
    if (STATE.filters.uf && meta.uf !== STATE.filters.uf) return;
    if (STATE.filters.regiao && meta.regiao !== STATE.filters.regiao) return;
    if (STATE.filters.dealers.size && !STATE.filters.dealers.has(meta.codigo)) return;
    const last = lastByDealer.get(meta.codigo);
    const dias = last != null ? Math.floor((now-last)/86400000) : null;
    result.push({ codigo: meta.codigo, nome: meta.nome, uf: meta.uf, cidade: meta.cidade, ultimo: last, dias });
  });
  result.sort((a,b)=> (b.dias==null?-1:b.dias) - (a.dias==null?-1:a.dias));
  return result;
}

// calculateCoverage(): % concessionárias treinadas no período / total ativas
function calculateCoverage(idxs, store){
  const trained = new Set();
  for (const i of idxs){
    if (isAprovado(store.situacaoAluno[i]) || stripAccents(store.statusMatricula[i]).toUpperCase()==='CONCLUIDO') trained.add(store.dealer[i]);
  }
  const byUF = new Map(), byRegiao = new Map();
  let totalDealers = 0, trainedDealers = 0;
  STATE.dealersByCode.forEach(meta=>{
    if (meta.segmento !== STATE.segment) return;
    if (STATE.filters.uf && meta.uf !== STATE.filters.uf) return;
    if (STATE.filters.regiao && meta.regiao !== STATE.filters.regiao) return;
    if (STATE.filters.dealers.size && !STATE.filters.dealers.has(meta.codigo)) return;
    totalDealers++;
    if (!byUF.has(meta.uf)) byUF.set(meta.uf, {total:0,trained:0});
    if (!byRegiao.has(meta.regiao)) byRegiao.set(meta.regiao, {total:0,trained:0});
    byUF.get(meta.uf).total++; byRegiao.get(meta.regiao).total++;
    if (trained.has(meta.codigo)){
      trainedDealers++;
      byUF.get(meta.uf).trained++; byRegiao.get(meta.regiao).trained++;
    }
  });
  return { totalDealers, trainedDealers, byUF, byRegiao, trainedSet: trained };
}

// calculatePendingByDealerAndCourse(): pendências (Aprovação=Não) por concessionária x curso
function calculatePendingByDealerAndCourse(idxs, store){
  const byDealerCourse = new Map(); // key `${dealer}||${curso}` -> count
  for (const i of idxs){
    if (store.aprovado[i]) continue;
    const key = store.dealer[i] + '||' + store.curso[i];
    byDealerCourse.set(key, (byDealerCourse.get(key)||0)+1);
  }
  return byDealerCourse;
}

// buildDealerCourseMatrix(): matriz concessionária x curso {aprovados,pendentes}
function buildDealerCourseMatrix(idxs, store, maxDealers, maxCourses){
  const dealerTotals = new Map(), courseTotals = new Map();
  for (const i of idxs){
    dealerTotals.set(store.dealer[i], (dealerTotals.get(store.dealer[i])||0)+1);
    courseTotals.set(store.curso[i], (courseTotals.get(store.curso[i])||0)+1);
  }
  const topDealers = [...dealerTotals.entries()].sort((a,b)=>b[1]-a[1]).slice(0,maxDealers).map(x=>x[0]);
  const topCourses = [...courseTotals.entries()].sort((a,b)=>b[1]-a[1]).slice(0,maxCourses).map(x=>x[0]);
  const dSet = new Set(topDealers), cSet = new Set(topCourses);
  const cell = new Map(); // `${dealer}||${curso}` -> {ok,pend}
  for (const i of idxs){
    const d = store.dealer[i], c = store.curso[i];
    if (!dSet.has(d) || !cSet.has(c)) continue;
    const key = d+'||'+c;
    if (!cell.has(key)) cell.set(key, {ok:0,pend:0});
    const o = cell.get(key);
    if (store.aprovado[i]) o.ok++; else o.pend++;
  }
  return { dealers: topDealers, courses: topCourses, cell };
}

// calculatePriorityScore(): score de criticidade normalizado (0-100)
function calculatePriorityScore(){
  const w = CONFIG.priorityWeights;
  const wSum = Object.values(w).reduce((a,b)=>a+b,0) || 1;
  const absence = calculateAbsenceDays(STATE.matricula? applyGlobalFilters(STATE.matricula,'matricula') : [], STATE.matricula || newMatriculaStore());
  const itMap = STATE.trilha ? calculateIT(applyGlobalFilters(STATE.trilha,'trilha'), STATE.trilha) : new Map();
  const pendMap = STATE.trilha ? calculatePendingByDealerAndCourse(applyGlobalFilters(STATE.trilha,'trilha'), STATE.trilha) : new Map();
  const pendByDealer = new Map();
  pendMap.forEach((v,k)=>{ const dealer = k.split('||')[0]; pendByDealer.set(dealer, (pendByDealer.get(dealer)||0)+v); });

  const maxDias = Math.max(1, ...absence.map(a=>a.dias||0));
  const maxPend = Math.max(1, ...pendByDealer.values());

  const rows = absence.map(a=>{
    const it = itMap.get(a.codigo);
    const itPct = it && it.pesoTotal ? it.pesoAprovado/it.pesoTotal : 0;
    const pend = pendByDealer.get(a.codigo) || 0;
    const nDias = (a.dias||0)/maxDias;
    const nPend = pend/maxPend;
    const nBaixoIT = 1-itPct;
    const nBaixoTSI = 0; // TSI não disponível nas bases enviadas — ponto de integração futura
    const nBaixaPart = it ? 0 : 1; // sem nenhum registro de trilha = baixa participação histórica
    const score = (nDias*w.diasSemTreinamento + nPend*w.pendencias + nBaixoIT*w.baixoIT + nBaixoTSI*w.baixoTSI + nBaixaPart*w.baixaParticipacao) / wSum * 100;
    return { codigo:a.codigo, nome:a.nome, uf:a.uf, dias:a.dias, pendencias:pend, itPct, score };
  });
  rows.sort((a,b)=>b.score-a.score);
  return rows;
}

// calculateTurnover(): treinados desligados / total de treinados
function calculateTurnover(idxs, store){
  const byDealer = new Map(), byCargo = new Map();
  const seenUser = new Set();
  for (const i of idxs){
    const concluded = isAprovado(store.situacaoAluno[i]) || stripAccents(store.statusMatricula[i]).toUpperCase()==='CONCLUIDO';
    if (!concluded) continue;
    const dealer = store.dealer[i], cargo = store.cargo[i]||'Não informado', inativo = isInativo(store.situacaoUsuario[i]) ? 1 : 0;
    if (!byDealer.has(dealer)) byDealer.set(dealer, {total:0,desligados:0});
    if (!byCargo.has(cargo)) byCargo.set(cargo, {total:0,desligados:0});
    byDealer.get(dealer).total++; byCargo.get(cargo).total++;
    if (inativo){ byDealer.get(dealer).desligados++; byCargo.get(cargo).desligados++; }
  }
  return { byDealer, byCargo };
}

// calculateClassDemand(): turmas sugeridas por curso (pendentes / capacidade)
function calculateClassDemand(idxs, store, capacity){
  const byCourse = new Map(); // curso -> Set(cpf pendente)
  for (const i of idxs){
    if (store.aprovado[i]) continue;
    const c = store.curso[i];
    if (!byCourse.has(c)) byCourse.set(c, new Set());
    byCourse.get(c).add(store.cpf[i] || (store.dealer[i]+'-'+i));
  }
  const rows = [];
  byCourse.forEach((set,curso)=>{
    const pendentes = set.size;
    rows.push({ curso, pendentes, turmas: Math.ceil(pendentes/Math.max(1,capacity)) });
  });
  rows.sort((a,b)=>b.pendentes-a.pendentes);
  return rows;
}

// calculateOccupancy(): ocupação por turma (matrícula)
function calculateOccupancy(idxs, store){
  const byTurma = new Map();
  for (const i of idxs){
    const t = store.turma[i] || 'Sem turma informada';
    if (!byTurma.has(t)) byTurma.set(t, {matriculados:0, concluidos:0});
    const o = byTurma.get(t);
    o.matriculados++;
    if (isAprovado(store.situacaoAluno[i]) || stripAccents(store.statusMatricula[i]).toUpperCase()==='CONCLUIDO') o.concluidos++;
  }
  return byTurma;
}

/* ========================================================================
   8) RENDER — dispatch por aba
======================================================================== */
function destroyChart(id){ if (STATE.charts[id]){ STATE.charts[id].destroy(); delete STATE.charts[id]; } }
function makeChart(id, cfg){ destroyChart(id); const ctx = document.getElementById(id); if(!ctx) return; STATE.charts[id] = new Chart(ctx, cfg); }

const PALETTE = ['#0e3a53','#c8912a','#155e75','#1a8754','#c0392b','#7c5cbf','#2f6f4e','#9c6b1c'];

function noDataState(container, msg){
  container.innerHTML = `<div class="empty-state"><div class="ico">📂</div><h4>Sem dados para exibir</h4><p>${msg || 'Envie os relatórios necessários na área de upload no topo da página, ou ajuste os filtros ativos.'}</p></div>`;
}

function renderActiveTab(){
  const tab = STATE.activeTab;
  document.getElementById('kiChip').textContent = `KI atual: ${currentKI()}KI`;
  try{
    switch(tab){
      case 'visaogeral': renderVisaoGeral(); break;
      case 'ausencia': renderAusencia(); break;
      case 'it': renderIT(); break;
      case 'itfuncao': renderITFuncao(); break;
      case 'cobertura': renderCobertura(); break;
      case 'pendencias': renderPendencias(); break;
      case 'matriz': renderMatriz(); break;
      case 'demanda': renderMap(); break;
      case 'ocupacaolocal': renderOcupacaoLocal(); break;
      case 'ocupacaoseg': renderOcupacaoSegmento(); break;
      case 'prioridade': renderPrioridade(); break;
      case 'turnover': renderTurnover(); break;
      case 'novasturmas': renderNovasTurmas(); break;
      case 'concessionarias': renderConcessionarias(); break;
    }
  }catch(err){
    console.error('Erro ao renderizar aba', tab, err);
    toast('Ocorreu um erro ao renderizar esta aba. Veja o console para detalhes.', 'error');
  }
}

/* ---- Visão Geral ---- */
function renderVisaoGeral(){
  const kpiEl = document.getElementById('vgKpis');
  const hasTrilha = !!STATE.trilha, hasMat = !!STATE.matricula;
  if (!hasTrilha && !hasMat){ noDataState(kpiEl); document.getElementById('vgTopCriticas').innerHTML=''; destroyChart('vgChartRegiao'); return; }

  const tIdx = hasTrilha ? applyGlobalFilters(STATE.trilha,'trilha') : [];
  const mIdx = hasMat ? applyGlobalFilters(STATE.matricula,'matricula') : [];
  const itMap = hasTrilha ? calculateIT(tIdx, STATE.trilha) : new Map();
  let sumAp=0,sumTot=0,sumPesoAp=0,sumPesoTot=0;
  itMap.forEach(o=>{sumAp+=o.aprovados;sumTot+=o.total;sumPesoAp+=o.pesoAprovado;sumPesoTot+=o.pesoTotal;});
  const itGeral = sumPesoTot ? sumPesoAp/sumPesoTot : 0;
  const cov = hasMat ? calculateCoverage(mIdx, STATE.matricula) : {totalDealers:0,trainedDealers:0};
  const absence = hasMat ? calculateAbsenceDays(mIdx, STATE.matricula) : [];
  const avgDias = absence.length ? Math.round(absence.filter(a=>a.dias!=null).reduce((s,a)=>s+a.dias,0) / Math.max(1,absence.filter(a=>a.dias!=null).length)) : null;
  const pendMap = hasTrilha ? calculatePendingByDealerAndCourse(tIdx, STATE.trilha) : new Map();
  let totalPend=0; pendMap.forEach(v=>totalPend+=v);

  kpiEl.innerHTML = `
    ${kpiCard('IT Geral', fmtPct(itGeral), `${sumAp.toLocaleString('pt-BR')} de ${sumTot.toLocaleString('pt-BR')} certificações`, itGeral>=.8?'good':itGeral>=.5?'warn':'bad')}
    ${kpiCard('Cobertura', fmtPct(cov.totalDealers? cov.trainedDealers/cov.totalDealers:0), `${cov.trainedDealers} de ${cov.totalDealers} concessionárias`, 'good')}
    ${kpiCard('Dias médios sem treinamento', avgDias!=null? avgDias : '—', 'média da rede filtrada', avgDias>90?'bad':avgDias>45?'warn':'good')}
    ${kpiCard('Pendências abertas', totalPend.toLocaleString('pt-BR'), 'combinações concessionária × curso', totalPend>0?'warn':'good')}
  `;

  // IT médio por região (média ponderada por peso do recurso)
  const byRegiao = new Map();
  STATE.dealersByCode.forEach(meta=>{
    if (meta.segmento!==STATE.segment) return;
    if (!byRegiao.has(meta.regiao)) byRegiao.set(meta.regiao, {pesoAp:0,pesoTot:0});
  });
  if (hasTrilha){
    for (const i of tIdx){
      const meta = dealerMeta(STATE.trilha.dealer[i]); if(!meta) continue;
      const o = byRegiao.get(meta.regiao) || {pesoAp:0,pesoTot:0};
      const peso = STATE.trilha.peso[i];
      o.pesoTot += peso; if (STATE.trilha.aprovado[i]) o.pesoAp += peso;
      byRegiao.set(meta.regiao, o);
    }
  }
  const regioes = [...byRegiao.keys()].sort();
  makeChart('vgChartRegiao', {
    type:'bar',
    data:{ labels: regioes.map(r=>REGIAO_NOME[r]||r), datasets:[{ label:'IT (%)', data: regioes.map(r=>{const o=byRegiao.get(r); return o.pesoTot? +(o.pesoAp/o.pesoTot*100).toFixed(1):0;}), backgroundColor: PALETTE[0], borderRadius:6 }]},
    options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{ y:{ suggestedMax:100, ticks:{callback:v=>v+'%'} } } }
  });

  // Top 10 críticas
  const prio = calculatePriorityScore().slice(0,10);
  document.getElementById('vgTopCriticas').innerHTML = prio.length ? prio.map((r,i)=>rankRow(i+1, dealerLabelByCode(r.codigo), r.score.toFixed(1)+' pts', Math.min(100,r.score), r.codigo, 'matricula')).join('') : '<div class="empty-state"><p>Sem dados suficientes.</p></div>';
}

function kpiCard(label, value, sub, tone){
  return `<div class="kpi-card ${tone||''}"><div class="kpi-label">${label}</div><div class="kpi-value">${value}</div><div class="kpi-sub">${sub||''}</div></div>`;
}
function rankRow(num, name, meta, pct, dealerCode, source){
  const cls = dealerCode ? 'rank-row rank-clickable' : 'rank-row';
  const dataAttrs = dealerCode ? ` data-dealer-code="${escapeHtml(dealerCode)}" data-source="${source||'matricula'}"` : '';
  return `<div class="${cls}"${dataAttrs}><div class="rank-num ${num<=3?'top':''}">${num}</div><div class="rank-name" title="${escapeHtml(name)}">${escapeHtml(name)}</div><div class="rank-track"><span style="width:${Math.max(2,Math.min(100,pct))}%"></span></div><div class="rank-meta">${meta}</div></div>`;
}

/* ---- Aba 1: Ausência ---- */
function renderAusencia(){
  if (!STATE.matricula){ noDataState(document.getElementById('ausKpis'), 'Envie o Relatório Geral de Matrícula para calcular ausência de treinamento.'); document.getElementById('ausRanking').innerHTML=''; document.getElementById('ausTable').innerHTML=''; destroyChart('ausChart'); return; }
  const idxs = applyGlobalFilters(STATE.matricula,'matricula');
  const rows = calculateAbsenceDays(idxs, STATE.matricula);
  const withDias = rows.filter(r=>r.dias!=null);
  const avg = withDias.length ? Math.round(withDias.reduce((s,r)=>s+r.dias,0)/withDias.length) : 0;
  const critico = rows.filter(r=>r.dias==null || r.dias>180).length;
  document.getElementById('ausKpis').innerHTML = `
    ${kpiCard('Média de dias sem treinamento', avg, `${withDias.length} concessionárias com histórico`, avg>90?'bad':avg>45?'warn':'good')}
    ${kpiCard('Concessionárias > 180 dias / nunca treinadas', critico, 'requer ação imediata', 'bad')}
    ${kpiCard('Total de concessionárias no filtro', rows.length, `segmento ${STATE.segment}`)}
  `;
  const top = rows.slice(0,15);
  makeChart('ausChart', {
    type:'bar',
    data:{ labels: top.map(r=>r.nome), datasets:[{ label:'Dias sem treinamento', data: top.map(r=>r.dias==null?0:r.dias), backgroundColor: top.map(r=>r.dias==null||r.dias>180?'#c0392b':r.dias>90?'#c8912a':'#1a8754'), borderRadius:6 }]},
    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}} }
  });
  document.getElementById('ausRanking').innerHTML = top.slice(0,10).map((r,i)=>rankRow(i+1, dealerLabelByCode(r.codigo), r.dias==null?'sem histórico':r.dias+' dias', r.dias==null?100:Math.min(100,r.dias/3), r.codigo, 'matricula')).join('');

  buildTable('ausTable', ['Concessionária','UF','Cidade','Último treinamento','Dias sem treinamento'],
    rows.map(r=>[dealerLabelByCode(r.codigo), r.uf, r.cidade, fmtDate(r.ultimo), r.dias==null? badge('Sem histórico','bad') : (r.dias>180?badge(r.dias+' dias','bad'):r.dias>90?badge(r.dias+' dias','warn'):badge(r.dias+' dias','good'))]),
    rows.map(r=>({ code:r.codigo, source:'matricula' })));
}
function badge(text, tone){ return `<span class="badge ${tone}">${text}</span>`; }

/* ---- Aba 2: IT Concessionária ---- */
function renderIT(){
  if (!STATE.trilha){ noDataState(document.getElementById('itKpis'), 'Envie os relatórios de Acompanhamento IT (2W e/ou 4W).'); document.getElementById('itRanking').innerHTML=''; document.getElementById('itTable').innerHTML=''; destroyChart('itChart'); return; }
  const idxs = applyGlobalFilters(STATE.trilha,'trilha');
  const map = calculateIT(idxs, STATE.trilha);
  let pesoAp=0,pesoTot=0; map.forEach(o=>{pesoAp+=o.pesoAprovado;pesoTot+=o.pesoTotal;});
  const rows = [...map.entries()].map(([code,o])=>{ const meta=dealerMeta(code); return {codigo:code, nome: meta?meta.nome:code, uf: meta?meta.uf:'', total:o.total, aprovados:o.aprovados, pesoTotal:o.pesoTotal, pesoAprovado:o.pesoAprovado, it: o.pesoTotal?o.pesoAprovado/o.pesoTotal:0}; });
  rows.sort((a,b)=>a.it-b.it);
  document.getElementById('itKpis').innerHTML = `
    ${kpiCard('IT Geral da rede', fmtPct(pesoTot?pesoAp/pesoTot:0), `${pesoAp.toLocaleString('pt-BR',{maximumFractionDigits:1})}/${pesoTot.toLocaleString('pt-BR',{maximumFractionDigits:1})} peso aprovado`, (pesoTot?pesoAp/pesoTot:0)>=.8?'good':'warn')}
    ${kpiCard('Concessionárias com IT < 50%', rows.filter(r=>r.it<0.5).length, 'atenção prioritária', 'bad')}
    ${kpiCard('Concessionárias com IT ≥ 90%', rows.filter(r=>r.it>=0.9).length, 'referência', 'good')}
  `;
  const bottom = rows.slice(0,15);
  makeChart('itChart', {
    type:'bar',
    data:{ labels: bottom.map(r=>r.nome), datasets:[{ label:'IT (%)', data: bottom.map(r=>+(r.it*100).toFixed(1)), backgroundColor: bottom.map(r=>r.it<0.5?'#c0392b':r.it<0.8?'#c8912a':'#1a8754'), borderRadius:6 }]},
    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{x:{suggestedMax:100,ticks:{callback:v=>v+'%'}}} }
  });
  document.getElementById('itRanking').innerHTML = bottom.slice(0,10).map((r,i)=>rankRow(i+1, dealerLabelByCode(r.codigo), fmtPct(r.it), r.it*100, r.codigo, 'trilha')).join('');
  buildTable('itTable', ['Concessionária','UF','Peso aprovado','Peso total','IT (média ponderada)'],
    rows.map(r=>[dealerLabelByCode(r.codigo), r.uf, r.pesoAprovado.toLocaleString('pt-BR',{maximumFractionDigits:1}), r.pesoTotal.toLocaleString('pt-BR',{maximumFractionDigits:1}), r.it>=0.8?badge(fmtPct(r.it),'good'):r.it>=0.5?badge(fmtPct(r.it),'warn'):badge(fmtPct(r.it),'bad')]),
    rows.map(r=>({ code:r.codigo, source:'trilha' })));
}

/* ---- Aba 3: IT por Função ---- */
function renderITFuncao(){
  if (!STATE.trilha){ noDataState(document.getElementById('itfTable')); destroyChart('itfChart'); return; }
  const idxs = applyGlobalFilters(STATE.trilha,'trilha');
  const map = calculateITPorFuncao(idxs, STATE.trilha);
  const rows = [...map.entries()].map(([cargo,o])=>({cargo, total:o.total, aprovados:o.aprovados, pesoTotal:o.pesoTotal, pesoAprovado:o.pesoAprovado, it:o.pesoTotal?o.pesoAprovado/o.pesoTotal:0}));
  rows.sort((a,b)=>b.total-a.total);
  const top = rows.slice(0,15);
  makeChart('itfChart', {
    type:'bar',
    data:{ labels: top.map(r=>r.cargo), datasets:[{ label:'IT por função (%)', data: top.map(r=>+(r.it*100).toFixed(1)), backgroundColor: PALETTE[2], borderRadius:6 }]},
    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{x:{suggestedMax:100,ticks:{callback:v=>v+'%'}}} }
  });
  buildTable('itfTable', ['Cargo/Função','Peso aprovado','Peso total','IT (média ponderada)'],
    rows.map(r=>[r.cargo, r.pesoAprovado.toLocaleString('pt-BR',{maximumFractionDigits:1}), r.pesoTotal.toLocaleString('pt-BR',{maximumFractionDigits:1}), r.it>=0.8?badge(fmtPct(r.it),'good'):r.it>=0.5?badge(fmtPct(r.it),'warn'):badge(fmtPct(r.it),'bad')]));
}

/* ---- Aba 4: Cobertura ---- */
function renderCobertura(){
  if (!STATE.matricula){ noDataState(document.getElementById('covKpis')); document.getElementById('covTable').innerHTML=''; destroyChart('covChart'); destroyChart('covChartRegiao'); return; }
  const idxs = applyGlobalFilters(STATE.matricula,'matricula');
  const cov = calculateCoverage(idxs, STATE.matricula);
  document.getElementById('covKpis').innerHTML = `
    ${kpiCard('Cobertura geral', fmtPct(cov.totalDealers?cov.trainedDealers/cov.totalDealers:0), `${cov.trainedDealers} de ${cov.totalDealers}`, 'good')}
    ${kpiCard('Concessionárias não treinadas', cov.totalDealers-cov.trainedDealers, 'no período filtrado', 'bad')}
  `;
  const ufs = [...cov.byUF.keys()].sort();
  makeChart('covChart', {
    type:'bar',
    data:{ labels: ufs, datasets:[{ label:'Cobertura (%)', data: ufs.map(u=>{const o=cov.byUF.get(u); return o.total?+(o.trained/o.total*100).toFixed(1):0;}), backgroundColor: PALETTE[1], borderRadius:6 }]},
    options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{y:{suggestedMax:100,ticks:{callback:v=>v+'%'}}} }
  });
  const regs = [...cov.byRegiao.keys()].sort();
  makeChart('covChartRegiao', {
    type:'doughnut',
    data:{ labels: regs.map(r=>REGIAO_NOME[r]||r), datasets:[{ data: regs.map(r=>cov.byRegiao.get(r).trained), backgroundColor: PALETTE }]},
    options:{ responsive:true, maintainAspectRatio:false }
  });
  const rows = [], rowMeta = [];
  STATE.dealersByCode.forEach(meta=>{
    if (meta.segmento!==STATE.segment) return;
    if (STATE.filters.uf && meta.uf!==STATE.filters.uf) return;
    if (STATE.filters.regiao && meta.regiao!==STATE.filters.regiao) return;
    if (STATE.filters.dealers.size && !STATE.filters.dealers.has(meta.codigo)) return;
    rows.push([dealerLabel(meta), meta.uf, meta.cidade, cov.trainedSet.has(meta.codigo)?badge('Treinada','good'):badge('Não treinada','bad')]);
    rowMeta.push({ code: meta.codigo, source:'matricula' });
  });
  buildTable('covTable', ['Concessionária','UF','Cidade','Status'], rows, rowMeta);
}

/* ---- Aba 5: Pendências ---- */
function renderPendencias(){
  if (!STATE.trilha){ noDataState(document.getElementById('pendTable')); destroyChart('pendChart'); return; }
  const idxs = applyGlobalFilters(STATE.trilha,'trilha');
  const map = calculatePendingByDealerAndCourse(idxs, STATE.trilha);

  // Tempo sem treinamento por concessionária, a partir do relatório de
  // matrícula (mesmo cálculo da aba "Ausência"). Se a matrícula ainda não
  // foi carregada, a coluna aparece como "sem histórico".
  const absenceByDealer = new Map();
  if (STATE.matricula){
    const mIdxs = applyGlobalFilters(STATE.matricula,'matricula');
    calculateAbsenceDays(mIdxs, STATE.matricula).forEach(a => absenceByDealer.set(a.codigo, a.dias));
  }

  const rows = [...map.entries()].map(([key,count])=>{
    const [code,curso]=key.split('||');
    const meta=dealerMeta(code);
    const dias = absenceByDealer.has(code) ? absenceByDealer.get(code) : null;
    return { codigo:code, nome: meta?meta.nome:code, uf: meta?meta.uf:'', curso, count, dias };
  });
  rows.sort((a,b)=>b.count-a.count);
  const top = rows.slice(0,15);
  makeChart('pendChart', {
    type:'bar',
    data:{ labels: top.map(r=>`${r.nome} · ${r.curso}`.slice(0,40)), datasets:[{ label:'Pendências', data: top.map(r=>r.count), backgroundColor: '#c0392b', borderRadius:6 }]},
    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}} }
  });
  buildTable('pendTable', ['Concessionária','UF','Curso','Pendências','Tempo sem treinamento'],
    rows.map(r=>[dealerLabelByCode(r.codigo), r.uf, r.curso, badge(r.count,'bad'),
      r.dias==null ? badge('sem histórico','neutral') : (r.dias>180?badge(r.dias+' dias','bad'):r.dias>90?badge(r.dias+' dias','warn'):badge(r.dias+' dias','good'))]),
    rows.map(r=>({ code:r.codigo, curso:r.curso, source:'trilha' })));
}

/* ---- Aba 6: Matriz ---- */
function renderMatriz(){
  const table = document.getElementById('matrixTable');
  if (!STATE.trilha){ table.innerHTML=''; noDataState(table.parentElement); return; }
  const idxs = applyGlobalFilters(STATE.trilha,'trilha');
  const { dealers, courses, cell } = buildDealerCourseMatrix(idxs, STATE.trilha, 60, 25);
  if (!dealers.length){ table.innerHTML=''; noDataState(table.parentElement); return; }
  let thead = '<thead><tr><th>Concessionária</th>' + courses.map(c=>`<th>${escapeHtml(c)}</th>`).join('') + '</tr></thead>';
  let tbody = '<tbody>' + dealers.map(d=>{
    const meta = dealerMeta(d);
    const cells = courses.map(c=>{
      const o = cell.get(d+'||'+c);
      if (!o) return '<td class="mx-cell mx-empty">—</td>';
      const cls = o.pend>0 ? 'mx-pending' : 'mx-ok';
      return `<td class="mx-cell ${cls}">${o.ok}/${o.pend}</td>`;
    }).join('');
    return `<tr><th>${escapeHtml(meta?dealerLabel(meta):d)}</th>${cells}</tr>`;
  }).join('') + '</tbody>';
  table.innerHTML = thead + tbody;
}

/* ---- Aba 7: Demanda reprimida (mapa) ---- */
/* ---- Geocodificação de cidades (para posicionar concessionárias em suas
   cidades exatas no mapa, em vez de apenas o centróide da UF) ----
   Usa a API pública Nominatim (OpenStreetMap) diretamente do navegador,
   com cache permanente em localStorage — cada cidade só precisa ser
   geocodificada UMA VEZ, em qualquer sessão futura já vem do cache.
   Respeita o limite de 1 requisição/segundo do Nominatim. */
const GEOCODE_CACHE = new Map();
const GEOCODE_STORAGE_KEY = 'pvDashboardGeocodeCacheV1';
function cityKey(cidade, uf){ return stripAccents(cidade).toUpperCase().trim()+'|'+normUpper(uf); }
function loadGeocodeCache(){
  try{
    const raw = localStorage.getItem(GEOCODE_STORAGE_KEY);
    if (raw){ const obj = JSON.parse(raw); Object.entries(obj).forEach(([k,v])=>GEOCODE_CACHE.set(k,v)); }
  }catch(e){ /* localStorage indisponível — segue sem cache persistente */ }
  // pré-carrega CITY_COORDS manuais (data.js), se preenchido
  Object.entries(CITY_COORDS).forEach(([k,v])=>{ if(!GEOCODE_CACHE.has(k)) GEOCODE_CACHE.set(k, v); });
}
function saveGeocodeCache(){
  try{
    const obj = {};
    GEOCODE_CACHE.forEach((v,k)=>{ if (v) obj[k]=v; });
    localStorage.setItem(GEOCODE_STORAGE_KEY, JSON.stringify(obj));
  }catch(e){ /* quota cheia ou bloqueado — ignora silenciosamente */ }
}
async function geocodeOne(cidade, uf){
  const key = cityKey(cidade, uf);
  if (GEOCODE_CACHE.has(key)) return GEOCODE_CACHE.get(key);
  try{
    const url = `https://nominatim.openstreetmap.org/search?city=${encodeURIComponent(cidade)}&state=${encodeURIComponent(uf)}&country=Brazil&format=json&limit=1`;
    const resp = await fetch(url, { headers: { 'Accept-Language':'pt-BR' } });
    const data = await resp.json();
    const coord = (data && data[0]) ? [parseFloat(data[0].lat), parseFloat(data[0].lon)] : null;
    GEOCODE_CACHE.set(key, coord);
    return coord;
  }catch(e){
    GEOCODE_CACHE.set(key, null);
    return null;
  }
}
// Geocodifica uma fila de cidades respeitando 1 req/s, com callback de progresso.
async function geocodeQueue(pairs, onProgress){
  const pending = pairs.filter(([cidade,uf]) => !GEOCODE_CACHE.has(cityKey(cidade,uf)));
  for (let i=0;i<pending.length;i++){
    const [cidade,uf] = pending[i];
    await geocodeOne(cidade, uf);
    onProgress && onProgress(i+1, pending.length);
    if (i < pending.length-1) await new Promise(r=>setTimeout(r, 1050));
  }
  if (pending.length) saveGeocodeCache();
  return pending.length;
}

let __leafletMap = null, __heatLayer = null, __cityMarkers = [], __mapLegend = null, __mapGeoStatus = null;
let __geocodeInProgress = false;
function renderMap(){
  const el = document.getElementById('map-demanda');
  if (!__leafletMap){
    loadGeocodeCache();
    __leafletMap = L.map(el, { preferCanvas:true }).setView([-14.2, -51.9], 4);
    // Basemap escuro (CartoDB Dark Matter) — o contraste faz as ondas de
    // calor (azul/verde/amarelo/vermelho) se destacarem muito mais do que
    // sobre um mapa claro padrão.
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; OpenStreetMap &copy; CARTO',
      subdomains: 'abcd', maxZoom: 19
    }).addTo(__leafletMap);
  }
  if (!STATE.trilha){
    if (__heatLayer){ __leafletMap.removeLayer(__heatLayer); __heatLayer=null; }
    __cityMarkers.forEach(m=>__leafletMap.removeLayer(m)); __cityMarkers=[];
    if (__mapLegend){ __leafletMap.removeControl(__mapLegend); __mapLegend=null; }
    return;
  }

  const idxs = applyGlobalFilters(STATE.trilha,'trilha');
  const pendMap = calculatePendingByDealerAndCourse(idxs, STATE.trilha);

  // Agrega pendências por CONCESSIONÁRIA (cada uma na sua própria cidade),
  // não apenas por UF — é isso que permite mostrar cada concessionária em
  // sua cidade exata no mapa.
  const byDealer = new Map(); // codigo -> count
  pendMap.forEach((count,key)=>{
    const code = key.split('||')[0];
    byDealer.set(code, (byDealer.get(code)||0)+count);
  });

  drawDemandLayer(byDealer);

  // Dispara geocodificação em segundo plano para as cidades ainda não
  // resolvidas (limitado às concessionárias com pendência no filtro atual),
  // e redesenha o mapa com precisão de cidade assim que cada lote termina.
  const pairs = [];
  byDealer.forEach((count,code)=>{
    const meta = dealerMeta(code); if (!meta || !meta.cidade) return;
    pairs.push([meta.cidade, meta.uf]);
  });
  const uniquePairs = [...new Map(pairs.map(p=>[cityKey(p[0],p[1]), p])).values()];
  const stillMissing = uniquePairs.filter(([c,u]) => !GEOCODE_CACHE.has(cityKey(c,u)));

  if (stillMissing.length && !__geocodeInProgress){
    __geocodeInProgress = true;
    updateGeoStatus(`Localizando ${stillMissing.length} cidade${stillMissing.length===1?'':'s'} de concessionárias...`);
    geocodeQueue(stillMissing, (done,total)=>{
      updateGeoStatus(`Localizando cidades... ${done}/${total}`);
    }).then(()=>{
      __geocodeInProgress = false;
      updateGeoStatus(null);
      if (STATE.activeTab === 'demanda') drawDemandLayer(byDealer);
    });
  } else if (!stillMissing.length){
    updateGeoStatus(null);
  }
}

function updateGeoStatus(msg){
  const el = document.getElementById('map-demanda');
  if (!el) return;
  if (!__mapGeoStatus){
    __mapGeoStatus = document.createElement('div');
    __mapGeoStatus.className = 'map-geo-status';
    el.appendChild(__mapGeoStatus);
  }
  if (msg){ __mapGeoStatus.textContent = msg; __mapGeoStatus.style.display = 'block'; }
  else { __mapGeoStatus.style.display = 'none'; }
}

// drawDemandLayer(): desenha o heatmap + marcadores por concessionária,
// usando coordenadas de cidade quando já geocodificadas (GEOCODE_CACHE),
// e caindo de volta no centróide da UF (com leve dispersão) para o restante.
function drawDemandLayer(byDealer){
  if (__heatLayer){ __leafletMap.removeLayer(__heatLayer); __heatLayer=null; }
  __cityMarkers.forEach(m=>__leafletMap.removeLayer(m)); __cityMarkers=[];
  if (__mapLegend){ __leafletMap.removeControl(__mapLegend); __mapLegend=null; }
  if (!byDealer.size) return;

  // Agrupa por cidade (concessionárias na mesma cidade somam-se num só pino)
  const byCity = new Map(); // cityKey -> {cidade,uf,count,coord}
  byDealer.forEach((count,code)=>{
    const meta = dealerMeta(code); if (!meta) return;
    const key = meta.cidade ? cityKey(meta.cidade, meta.uf) : ('UF|'+meta.uf);
    if (!byCity.has(key)){
      const geo = meta.cidade ? GEOCODE_CACHE.get(cityKey(meta.cidade, meta.uf)) : null;
      const coord = geo || UF_COORDS[meta.uf];
      byCity.set(key, { cidade: meta.cidade, uf: meta.uf, count: 0, coord, precise: !!geo, dealers: new Set() });
    }
    const o = byCity.get(key);
    o.count += count;
    o.dealers.add(dealerLabel(meta));
  });

  const maxV = Math.max(1, ...[...byCity.values()].map(o=>o.count));
  const points = [];
  byCity.forEach(o=>{
    if (!o.coord) return;
    const intensity = o.count/maxV;
    const density = Math.max(5, Math.round(intensity*40));
    // Sem coordenada precisa de cidade (fallback UF), aplica leve dispersão
    // para não empilhar tudo num único ponto do centróide da UF.
    const spread = o.precise ? 0.02 : (0.9 + intensity*0.5);
    for (let k=0;k<density;k++){
      points.push([o.coord[0] + (Math.random()-0.5)*spread, o.coord[1] + (Math.random()-0.5)*spread, Math.max(0.35, intensity)]);
    }
  });

  __heatLayer = L.heatLayer(points, {
    radius: 34,
    blur: 26,
    maxZoom: 11,
    minOpacity: 0.45,
    gradient: { 0.0:'#1e3a8a', 0.25:'#0891b2', 0.5:'#22c55e', 0.7:'#facc15', 0.85:'#f97316', 1.0:'#dc2626' }
  }).addTo(__leafletMap);

  // Marcadores por cidade com o número exato — e nome da(s) concessionária(s).
  byCity.forEach(o=>{
    if (!o.coord) return;
    const intensity = o.count/maxV;
    const color = intensity>0.7?'#dc2626':intensity>0.4?'#f97316':intensity>0.15?'#facc15':'#22c55e';
    const marker = L.circleMarker(o.coord, {
      radius: o.precise ? (7 + intensity*8) : (9 + intensity*10),
      color: '#fff', weight: o.precise?1.5:1, fillColor: color, fillOpacity: o.precise?0.95:0.55
    }).addTo(__leafletMap);
    const dealerList = [...o.dealers].slice(0,6).join(', ') + (o.dealers.size>6?` e mais ${o.dealers.size-6}...`:'');
    const label = o.cidade ? `${o.cidade}/${o.uf}` : o.uf;
    marker.bindTooltip(
      `<strong>${label}</strong> — ${o.count.toLocaleString('pt-BR')} pendência${o.count===1?'':'s'}`,
      { permanent: true, direction: 'top', offset: [0,-6], className: 'uf-heat-label' }
    );
    marker.bindPopup(`<strong>${label}</strong><br>${o.count.toLocaleString('pt-BR')} pendência${o.count===1?'':'s'} de treinamento<br><span style="font-size:11px;color:#666;">${dealerList}</span>`);
    __cityMarkers.push(marker);
  });

  // Legenda de intensidade
  __mapLegend = L.control({ position: 'bottomright' });
  __mapLegend.onAdd = function(){
    const div = L.DomUtil.create('div', 'map-heat-legend');
    const top = [...byCity.values()].sort((a,b)=>b.count-a.count)[0];
    div.innerHTML = `
      <div class="map-heat-legend-title">Demanda reprimida</div>
      <div class="map-heat-legend-scale"></div>
      <div class="map-heat-legend-labels"><span>baixa</span><span>alta</span></div>
      <div class="map-heat-legend-max">máx.: ${maxV.toLocaleString('pt-BR')} pendências (${top.cidade?top.cidade+'/'+top.uf:top.uf})</div>
    `;
    return div;
  };
  __mapLegend.addTo(__leafletMap);

  setTimeout(()=>__leafletMap.invalidateSize(), 200);
}

/* ---- Aba 8: Ocupação por local ---- */
function renderOcupacaoLocal(){
  if (!STATE.matricula){ noDataState(document.getElementById('ocuRanking')); destroyChart('ocuChart'); return; }
  const idxs = applyGlobalFilters(STATE.matricula,'matricula');
  const map = calculateOccupancy(idxs, STATE.matricula);
  const rows = [...map.entries()].map(([turma,o])=>({turma, ...o, taxa:o.matriculados?o.concluidos/o.matriculados:0}));
  rows.sort((a,b)=>b.matriculados-a.matriculados);
  const top = rows.slice(0,15);
  makeChart('ocuChart', {
    type:'bar',
    data:{ labels: top.map(r=>r.turma), datasets:[
      { label:'Matriculados', data: top.map(r=>r.matriculados), backgroundColor: PALETTE[2], borderRadius:6 },
      { label:'Concluídos', data: top.map(r=>r.concluidos), backgroundColor: PALETTE[1], borderRadius:6 }
    ]},
    options:{ responsive:true, maintainAspectRatio:false }
  });
  const bySub = rows.slice().sort((a,b)=>a.taxa-b.taxa).slice(0,10);
  document.getElementById('ocuRanking').innerHTML = bySub.map((r,i)=>rankRow(i+1, r.turma, fmtPct(r.taxa), r.taxa*100)).join('') || '<div class="empty-state"><p>Sem dados.</p></div>';
}

/* ---- Aba 9: Ocupação por segmento ---- */
function renderOcupacaoSegmento(){
  const el = document.getElementById('segKpis');
  document.getElementById('mmNote').textContent = 'M&M (Marine & Power) não está disponível nos arquivos recebidos. A estrutura de agregação por segmento já contempla essa categoria — basta que os dados de M&M sejam vinculados à base de concessionárias (DEALERS_DB) com segmento "M&M" em uma próxima carga.';
  if (!STATE.matricula){ noDataState(el); destroyChart('segChart'); return; }
  const f = STATE.filters;
  const hasDealerFilter = f.dealers.size > 0;
  let kiWindow = null; if (f.ki) kiWindow = kiRange(Number(f.ki));
  const custIni = f.dataInicio ? new Date(f.dataInicio+'T00:00:00').getTime() : null;
  const custFim = f.dataFim ? new Date(f.dataFim+'T23:59:59').getTime() : null;
  const store = STATE.matricula;
  const counts = { '2W':0, '4W':0, 'M&M':0 };
  for (let i=0;i<store.n;i++){
    const meta = dealerMeta(store.dealer[i]); if (!meta) continue;
    if (f.masterPresencialBlended && !isPresencialOuBlended(store.modalidade[i])) continue;
    if (f.uf && meta.uf!==f.uf) continue;
    if (f.regiao && meta.regiao!==f.regiao) continue;
    if (hasDealerFilter && !f.dealers.has(meta.codigo)) continue;
    if (f.cargo && store.cargo[i] !== f.cargo) continue;
    if (f.curso && store.curso[i] !== f.curso) continue;
    const dref = store.dataConclusao[i] != null ? store.dataConclusao[i] : store.dataInicio[i];
    if (kiWindow && dref != null && (dref < kiWindow.start || dref > kiWindow.end)) continue;
    if ((custIni || custFim) && dref != null){
      if (custIni && dref < custIni) continue;
      if (custFim && dref > custFim) continue;
    }
    counts[meta.segmento] = (counts[meta.segmento]||0)+1;
  }
  el.innerHTML = `${kpiCard('2W', counts['2W'].toLocaleString('pt-BR'), 'matrículas no filtro atual')}${kpiCard('4W', counts['4W'].toLocaleString('pt-BR'), 'matrículas no filtro atual')}${kpiCard('M&M', counts['M&M']||0, 'estrutura pronta — sem dados na base atual','warn')}`;
  makeChart('segChart', {
    type:'bar',
    data:{ labels:['2W','4W','M&M'], datasets:[{ label:'Matrículas no filtro atual', data:[counts['2W'],counts['4W'],counts['M&M']||0], backgroundColor:[PALETTE[0],PALETTE[1],PALETTE[3]], borderRadius:8 }]},
    options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}} }
  });
}

/* ---- Aba 10: Prioridade ---- */
function renderPrioridade(){
  const wrap = document.getElementById('priorityWeights');
  wrap.innerHTML = Object.entries(CONFIG.priorityWeights).map(([k,v])=>`
    <div class="config-item">
      <label>${prioLabel(k)}</label>
      <input type="range" min="0" max="50" value="${v}" data-weight="${k}">
      <span class="val">${v}</span>
    </div>`).join('');
  wrap.querySelectorAll('input[type=range]').forEach(r=>{
    r.addEventListener('input', ()=>{ CONFIG.priorityWeights[r.dataset.weight] = Number(r.value); r.nextElementSibling.textContent = r.value; renderPrioridadeTable(); renderVisaoGeral_safe(); });
  });
  renderPrioridadeTable();
}
function renderVisaoGeral_safe(){ if (STATE.activeTab==='visaogeral') renderVisaoGeral(); }
function prioLabel(k){
  return { diasSemTreinamento:'Dias sem treinamento', pendencias:'Pendências obrigatórias', baixoIT:'Baixo IT', baixoTSI:'Baixo TSI (futuro)', baixaParticipacao:'Baixa participação histórica' }[k] || k;
}
function renderPrioridadeTable(){
  if (!STATE.trilha && !STATE.matricula){ noDataState(document.getElementById('prioTable').parentElement); return; }
  const rows = calculatePriorityScore();
  buildTable('prioTable', ['Concessionária','UF','Dias sem treinamento','Pendências','IT','Score de prioridade'],
    rows.map(r=>[dealerLabelByCode(r.codigo), r.uf, r.dias==null?'—':r.dias, r.pendencias, fmtPct(r.itPct), r.score>=66?badge(r.score.toFixed(1),'bad'):r.score>=33?badge(r.score.toFixed(1),'warn'):badge(r.score.toFixed(1),'good')]),
    rows.map(r=>({ code:r.codigo, source:'matricula' })));
}

/* ---- Aba 11: Turnover ---- */
function renderTurnover(){
  if (!STATE.matricula){ noDataState(document.getElementById('turnKpis')); document.getElementById('turnTable').innerHTML=''; destroyChart('turnChart'); return; }
  const idxs = applyGlobalFilters(STATE.matricula,'matricula');
  const { byDealer, byCargo } = calculateTurnover(idxs, STATE.matricula);
  let tot=0, desl=0; byDealer.forEach(o=>{tot+=o.total; desl+=o.desligados;});
  document.getElementById('turnKpis').innerHTML = `
    ${kpiCard('Turnover geral', fmtPct(tot?desl/tot:0), `${desl} de ${tot} treinados`, (tot?desl/tot:0)>0.2?'bad':'good')}
    ${kpiCard('Concessionárias analisadas', byDealer.size, `segmento ${STATE.segment}`)}
  `;
  const rows = [...byDealer.entries()].map(([code,o])=>{ const meta=dealerMeta(code); return {nome:meta?meta.nome:code, total:o.total, desl:o.desligados, taxa:o.total?o.desligados/o.total:0}; });
  rows.sort((a,b)=>b.taxa-a.taxa);
  const top = rows.slice(0,15);
  makeChart('turnChart', {
    type:'bar',
    data:{ labels: top.map(r=>r.nome), datasets:[{ label:'Turnover (%)', data: top.map(r=>+(r.taxa*100).toFixed(1)), backgroundColor:'#c0392b', borderRadius:6 }]},
    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}} }
  });
  const cargoRows = [...byCargo.entries()].map(([cargo,o])=>[cargo, o.total, o.desligados, fmtPct(o.total?o.desligados/o.total:0)]);
  buildTable('turnTable', ['Cargo','Total treinados','Desligados','Turnover'], cargoRows);
}

/* ---- Aba 12: Novas turmas ---- */
function renderNovasTurmas(){
  if (!STATE.trilha){ noDataState(document.getElementById('turmaTable').parentElement); return; }
  const idxs = applyGlobalFilters(STATE.trilha,'trilha');
  const rows = calculateClassDemand(idxs, STATE.trilha, CONFIG.classCapacity);
  buildTable('turmaTable', ['Curso','Elegíveis pendentes','Capacidade/turma','Turmas sugeridas'],
    rows.map(r=>[r.curso, r.pendentes, CONFIG.classCapacity, badge(r.turmas,r.turmas>5?'bad':r.turmas>0?'warn':'good')]));
}

/* ---- Aba 13: Dados concessionárias ---- */
function renderConcessionarias(){
  const rows = [], rowMeta = [];
  const itMap = STATE.trilha ? calculateIT(applyGlobalFilters(STATE.trilha,'trilha'), STATE.trilha) : new Map();
  const cadastradosByDealer = new Map();
  if (STATE.matricula){
    const idxs = applyGlobalFilters(STATE.matricula,'matricula');
    const seen = new Map();
    for (const i of idxs){
      const d = STATE.matricula.dealer[i];
      if (!seen.has(d)) seen.set(d, new Set());
      seen.get(d).add(STATE.matricula.cpf[i] || i);
    }
    seen.forEach((set,d)=>cadastradosByDealer.set(d, set.size));
  }
  STATE.dealersByCode.forEach(meta=>{
    if (meta.segmento!==STATE.segment) return;
    if (STATE.filters.uf && meta.uf!==STATE.filters.uf) return;
    if (STATE.filters.regiao && meta.regiao!==STATE.filters.regiao) return;
    if (STATE.filters.dealers.size && !STATE.filters.dealers.has(meta.codigo)) return;
    const it = itMap.get(meta.codigo);
    const itPct = it && it.pesoTotal ? it.pesoAprovado/it.pesoTotal : null;
    rows.push([
      meta.codigo, meta.nome, meta.uf, meta.cidade,
      cadastradosByDealer.get(meta.codigo) || 0,
      it ? it.total : 0,
      itPct!=null ? badge(fmtPct(itPct), itPct>=0.8?'good':itPct>=0.5?'warn':'bad') : badge('sem dados','neutral')
    ]);
    rowMeta.push({ code: meta.codigo, source:'matricula' });
  });
  buildTable('dealerTable', ['Código','Concessionária','UF','Cidade','Colaboradores cadastrados','Colaboradores elegíveis','IT'], rows, rowMeta);
}

/* ========================================================================
   Tabelas genéricas (ordenação + busca)
======================================================================== */
// buildTable(): rowMeta (opcional) é um array paralelo a rows, com
// {code, curso} por linha — usado para permitir clicar numa linha e ver a
// lista de alunos correspondente (drill-down), e para o botão de exportação.
function buildTable(id, headers, rows, rowMeta){
  const table = document.getElementById(id);
  if (!rows.length){ table.parentElement.innerHTML = ''; noDataState(table.parentElement.parentElement || table.parentElement); return; }
  table.dataset.raw = '';
  table._rows = rows;
  table._rowMeta = rowMeta || null;
  table._headers = headers;
  table._sortCol = -1; table._sortDir = 1;
  renderTableDom(table);
}
function renderTableDom(table, filterTerm){
  const headers = table._headers, rows0 = table._rows, meta0 = table._rowMeta;
  let idxs = rows0.map((_,i)=>i);
  if (filterTerm){
    const t = stripAccents(filterTerm).toUpperCase();
    idxs = idxs.filter(i => rows0[i].some(c => stripAccents(String(c).replace(/<[^>]+>/g,'')).toUpperCase().includes(t)));
  }
  if (table._sortCol >= 0){
    idxs = idxs.slice().sort((ia,ib)=>{
      const av = rows0[ia][table._sortCol], bv = rows0[ib][table._sortCol];
      const an = parseFloat(String(av).replace(/[^\d.-]/g,'')), bn = parseFloat(String(bv).replace(/[^\d.-]/g,''));
      let cmp;
      if (!isNaN(an) && !isNaN(bn) && /^[\d.,%\s<>a-z"'=-]*$/i.test(String(av))) cmp = an-bn;
      else cmp = String(av).localeCompare(String(bv), 'pt-BR');
      return cmp * table._sortDir;
    });
  }
  table._visibleIdxs = idxs; // usado pelo botão de exportação (respeita busca + ordenação)
  const thead = '<thead><tr>' + headers.map((h,i)=>`<th data-col="${i}" class="${table._sortCol===i?'sorted':''}">${h}</th>`).join('') + '</tr></thead>';
  const MAX_RENDER = 2000;
  const shown = idxs.slice(0, MAX_RENDER);
  const tbody = '<tbody>' + shown.map(i=>{
    const r = rows0[i], m = meta0 ? meta0[i] : null;
    const clickable = m && m.code;
    const attrs = clickable ? ` class="row-clickable" data-dealer-code="${escapeHtml(m.code)}"${m.curso?` data-curso="${escapeHtml(m.curso)}"`:''}${m.source?` data-source="${m.source}"`:''}` : '';
    return `<tr${attrs}>${r.map(c=>`<td>${c}</td>`).join('')}</tr>`;
  }).join('') + '</tbody>';
  table.innerHTML = thead + tbody;
  table.querySelectorAll('thead th').forEach(th=>{
    th.onclick = ()=>{
      const col = Number(th.dataset.col);
      table._sortDir = (table._sortCol===col) ? -table._sortDir : 1;
      table._sortCol = col;
      renderTableDom(table, filterTerm);
    };
  });
  if (idxs.length > MAX_RENDER){
    const note = document.createElement('div');
    note.className = 'footnote';
    note.style.padding = '8px 4px';
    note.textContent = `Exibindo ${MAX_RENDER.toLocaleString('pt-BR')} de ${idxs.length.toLocaleString('pt-BR')} linhas. Refine os filtros para ver o restante (a exportação para Excel inclui todas as linhas filtradas).`;
    table.parentElement.appendChild(note);
  }
}

/* ========================================================================
   8-A) MODAL DE ALUNOS (drill-down) — clique em concessionária/linha para
   ver a lista de alunos por trás daquele número, respeitando os filtros
   globais ativos no momento.
======================================================================== */
function getStudentsByDealerMatricula(code){
  if (!STATE.matricula) return [];
  const idxs = applyGlobalFilters(STATE.matricula, 'matricula');
  const seen = new Map();
  for (const i of idxs){
    if (STATE.matricula.dealer[i] !== code) continue;
    const cpf = STATE.matricula.cpf[i] || ('linha'+i);
    if (!seen.has(cpf)){
      seen.set(cpf, { nome: STATE.matricula.usuario[i] || '(nome não informado)', extra: STATE.matricula.cargo[i] || '' });
    }
  }
  return [...seen.values()].sort((a,b)=>a.nome.localeCompare(b.nome,'pt-BR'));
}
function getStudentsByDealerTrilha(code){
  if (!STATE.trilha) return [];
  const idxs = applyGlobalFilters(STATE.trilha, 'trilha');
  const byUser = new Map();
  for (const i of idxs){
    if (STATE.trilha.dealer[i] !== code) continue;
    const cpf = STATE.trilha.cpf[i] || ('linha'+i);
    if (!byUser.has(cpf)) byUser.set(cpf, { nome: STATE.trilha.usuario[i] || '(nome não informado)', cargo: STATE.trilha.cargo[i]||'', pesoAp:0, pesoTot:0 });
    const o = byUser.get(cpf);
    const peso = STATE.trilha.peso[i];
    o.pesoTot += peso;
    if (STATE.trilha.aprovado[i]) o.pesoAp += peso;
  }
  return [...byUser.values()].map(o=>({ nome:o.nome, extra: `${o.cargo ? o.cargo+' · ':''}IT ${fmtPct(o.pesoTot?o.pesoAp/o.pesoTot:0)}` })).sort((a,b)=>a.nome.localeCompare(b.nome,'pt-BR'));
}
function getStudentsPendingCourse(code, curso){
  if (!STATE.trilha) return [];
  const idxs = applyGlobalFilters(STATE.trilha, 'trilha');
  const seen = new Map();
  for (const i of idxs){
    if (STATE.trilha.dealer[i] !== code || STATE.trilha.curso[i] !== curso) continue;
    if (STATE.trilha.aprovado[i]) continue; // somente pendentes
    const cpf = STATE.trilha.cpf[i] || ('linha'+i);
    if (!seen.has(cpf)) seen.set(cpf, { nome: STATE.trilha.usuario[i] || '(nome não informado)', extra: STATE.trilha.cargo[i]||'' });
  }
  return [...seen.values()].sort((a,b)=>a.nome.localeCompare(b.nome,'pt-BR'));
}

let __modalStudentsFull = [];
function openStudentModal(title, subtitle, students){
  __modalStudentsFull = students;
  document.getElementById('studentModalTitle').textContent = title;
  document.getElementById('studentModalSubtitle').textContent = subtitle || `${students.length} aluno${students.length===1?'':'s'}`;
  document.getElementById('studentModalSearch').value = '';
  renderStudentModalList(students);
  document.getElementById('studentModalOverlay').classList.add('open');
}
function renderStudentModalList(students){
  const el = document.getElementById('studentModalList');
  if (!students.length){ el.innerHTML = '<div class="empty-state"><p>Nenhum aluno encontrado para este filtro.</p></div>'; return; }
  el.innerHTML = students.map(s=>`<div class="student-row"><span class="student-name">${escapeHtml(s.nome)}</span>${s.extra?`<span class="student-extra">${escapeHtml(s.extra)}</span>`:''}</div>`).join('');
}
function closeStudentModal(){ document.getElementById('studentModalOverlay').classList.remove('open'); }

function wireStudentModal(){
  document.getElementById('studentModalClose').addEventListener('click', closeStudentModal);
  document.getElementById('studentModalOverlay').addEventListener('click', (e)=>{ if (e.target.id==='studentModalOverlay') closeStudentModal(); });
  document.addEventListener('keydown', (e)=>{ if (e.key==='Escape') closeStudentModal(); });
  document.getElementById('studentModalSearch').addEventListener('input', (e)=>{
    const t = stripAccents(e.target.value).toUpperCase();
    renderStudentModalList(t ? __modalStudentsFull.filter(s=>stripAccents(s.nome).toUpperCase().includes(t)) : __modalStudentsFull);
  });

  // Delegação de clique: linhas de tabela (buildTable) e rank-rows
  document.addEventListener('click', (e)=>{
    const tr = e.target.closest('tr.row-clickable');
    if (tr){
      const code = tr.dataset.dealerCode;
      const curso = tr.dataset.curso;
      const meta = dealerMeta(code);
      const label = meta ? dealerLabel(meta) : code;
      let students, subtitle;
      if (curso){
        students = getStudentsPendingCourse(code, curso);
        subtitle = `${label} · pendentes em "${curso}"`;
      } else if (tr.dataset.source === 'trilha'){
        students = getStudentsByDealerTrilha(code);
        subtitle = `${label} · base de trilhas (IT)`;
      } else {
        students = getStudentsByDealerMatricula(code);
        subtitle = `${label} · matrículas no filtro atual`;
      }
      openStudentModal(label, subtitle, students);
      return;
    }
    const rr = e.target.closest('.rank-row.rank-clickable');
    if (rr){
      const code = rr.dataset.dealerCode;
      const meta = dealerMeta(code);
      const label = meta ? dealerLabel(meta) : code;
      const source = rr.dataset.source || 'matricula';
      const students = source === 'trilha' ? getStudentsByDealerTrilha(code) : getStudentsByDealerMatricula(code);
      openStudentModal(label, `${label} · ${source==='trilha'?'base de trilhas (IT)':'matrículas no filtro atual'}`, students);
    }
  });
}

/* ========================================================================
   8-B) EXPORTAÇÃO PARA EXCEL — exporta a tabela da aba ativa, já filtrada
   e ordenada exatamente como está na tela.
======================================================================== */
const TAB_EXPORT_TABLE = {
  ausencia: 'ausTable', it: 'itTable', itfuncao: 'itfTable', cobertura: 'covTable',
  pendencias: 'pendTable', prioridade: 'prioTable', turnover: 'turnTable',
  novasturmas: 'turmaTable', concessionarias: 'dealerTable'
};
function exportActiveTabToExcel(){
  const tableId = TAB_EXPORT_TABLE[STATE.activeTab];
  if (!tableId){
    toast('Esta aba não possui uma tabela para exportar. Vá para uma aba com lista/tabela (ex.: IT, Ausência, Pendências).', 'warn');
    return;
  }
  const table = document.getElementById(tableId);
  if (!table || !table._rows || !table._rows.length){
    toast('Não há dados carregados nesta aba para exportar ainda.', 'warn');
    return;
  }
  const idxs = table._visibleIdxs && table._visibleIdxs.length ? table._visibleIdxs : table._rows.map((_,i)=>i);
  const headers = table._headers;
  const stripTags = (v) => String(v).replace(/<[^>]+>/g,'').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').trim();
  const aoa = [headers, ...idxs.map(i => table._rows[i].map(stripTags))];

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  XLSX.utils.book_append_sheet(wb, ws, STATE.activeTab.slice(0,31));

  // Segunda aba com um resumo dos filtros ativos no momento da exportação.
  const f = STATE.filters;
  const filterSummary = [
    ['Filtro','Valor'],
    ['Segmento', STATE.segment],
    ['Somente Presencial & Blended', f.masterPresencialBlended ? 'Sim' : 'Não'],
    ['UF', f.uf || 'Todas'],
    ['Região', f.regiao || 'Todas'],
    ['Concessionárias selecionadas', f.dealers.size ? [...f.dealers].map(c=>dealerLabelByCode(c)).join(', ') : 'Todas'],
    ['Curso', f.curso || 'Todos'],
    ['Cargo', f.cargo || 'Todos'],
    ['Período fiscal (KI)', f.ki || 'Todos'],
    ['Data início', f.dataInicio || '—'],
    ['Data fim', f.dataFim || '—'],
    ['Exportado em', new Date().toLocaleString('pt-BR')]
  ];
  const wsF = XLSX.utils.aoa_to_sheet(filterSummary);
  XLSX.utils.book_append_sheet(wb, wsF, 'Filtros aplicados');

  const filename = `dashboard-${STATE.activeTab}-${STATE.segment}-${new Date().toISOString().slice(0,10)}.xlsx`;
  XLSX.writeFile(wb, filename);
  toast(`Exportado: ${filename}`, 'success');
}
function wireExportButton(){
  document.getElementById('btnExportExcel').addEventListener('click', exportActiveTabToExcel);
}

/* ========================================================================
   9) Bootstrap / listeners
======================================================================== */
function buildDealersIndex(){
  DEALERS_DB.forEach(([codigo,nome,cidade,uf,segmento])=>{
    const ufN = normUpper(uf);
    STATE.dealersByCode.set(codigo, { codigo, nome, cidade, uf: ufN, segmento, regiao: UF_REGIAO[ufN] || '' });
  });
}

function wireTabs(){
  document.getElementById('tabbar').addEventListener('click', (e)=>{
    const btn = e.target.closest('button[data-tab]'); if (!btn) return;
    document.querySelectorAll('.tabbar button').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));
    document.getElementById('tab-'+btn.dataset.tab).classList.add('active');
    STATE.activeTab = btn.dataset.tab;
    renderActiveTab();
  });
}
function wireSegmentToggle(){
  document.getElementById('segmentToggle').addEventListener('click', (e)=>{
    const btn = e.target.closest('button[data-seg]'); if (!btn) return;
    document.querySelectorAll('.segment-toggle button').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    STATE.segment = btn.dataset.seg;
    STATE.filters.dealers.clear();
    window.__renderDealerChips && window.__renderDealerChips();
    rebuildFilterOptions();
    renderActiveTab();
  });
}
function wireMasterToggle(){
  const btn = document.getElementById('masterToggle');
  btn.addEventListener('click', ()=>{
    STATE.filters.masterPresencialBlended = !STATE.filters.masterPresencialBlended;
    btn.classList.toggle('active', STATE.filters.masterPresencialBlended);
    btn.setAttribute('aria-checked', String(STATE.filters.masterPresencialBlended));
    toast(STATE.filters.masterPresencialBlended
      ? 'Mostrando somente treinamentos Presencial & Blended.'
      : 'Mostrando todas as modalidades (Presencial, Blended, A Distância, Prova, Síncrono...).', 'success');
    rebuildFilterOptions();
    renderActiveTab();
  });
}
function wireFilters(){
  const ids = { fUF:'uf', fRegiao:'regiao', fCurso:'curso', fCargo:'cargo', fKI:'ki', fDataInicio:'dataInicio', fDataFim:'dataFim' };
  Object.entries(ids).forEach(([elId,key])=>{
    document.getElementById(elId).addEventListener('change', (e)=>{ STATE.filters[key] = e.target.value; renderActiveTab(); });
  });
  document.getElementById('btnClearFilters').addEventListener('click', ()=>{
    const keepMaster = STATE.filters.masterPresencialBlended;
    STATE.filters = { uf:'', regiao:'', dealers:new Set(), curso:'', cargo:'', ki:'', dataInicio:'', dataFim:'', masterPresencialBlended: keepMaster };
    document.getElementById('fUF').value=''; document.getElementById('fRegiao').value='';
    document.getElementById('fCurso').value=''; document.getElementById('fCargo').value='';
    document.getElementById('fKI').value=''; document.getElementById('fDataInicio').value=''; document.getElementById('fDataFim').value='';
    window.__renderDealerChips && window.__renderDealerChips();
    rebuildFilterOptions();
    renderActiveTab();
  });
  document.addEventListener('input', (e)=>{
    if (e.target.matches('input[type=search][data-table]')){
      const table = document.getElementById(e.target.dataset.table);
      if (table && table._rows) renderTableDom(table, e.target.value);
    }
  });
  document.getElementById('classCapacityRange').addEventListener('input', (e)=>{
    CONFIG.classCapacity = Number(e.target.value);
    document.getElementById('classCapacityVal').textContent = e.target.value;
    if (STATE.activeTab === 'novasturmas') renderNovasTurmas();
  });
}
function wireUploads(){
  document.getElementById('fileTrilha2W').addEventListener('change', (e)=>handleTrilhaUpload(e.target.files[0], '2W'));
  document.getElementById('fileTrilha4W').addEventListener('change', (e)=>handleTrilhaUpload(e.target.files[0], '4W'));
  document.getElementById('fileMatriculas').addEventListener('change', (e)=>handleMatriculaUpload(e.target.files[0]));
}

function checkExternalLibs(){
  const missing = [];
  if (typeof XLSX === 'undefined') missing.push('SheetJS (leitura de Excel)');
  if (typeof Chart === 'undefined') missing.push('Chart.js (gráficos)');
  if (typeof L === 'undefined') missing.push('Leaflet (mapa)');
  if (typeof Papa === 'undefined') missing.push('PapaParse (leitura de CSV)');
  return missing;
}

function showFatalError(title, details){
  const box = document.createElement('div');
  box.style.cssText = 'position:fixed;inset:0;background:#0f1720;color:#fff;z-index:99999;display:flex;align-items:center;justify-content:center;padding:24px;font-family:sans-serif;';
  box.innerHTML = `<div style="max-width:560px;background:#1a2530;border-radius:14px;padding:28px;border:1px solid rgba(255,255,255,.12);">
    <div style="font-size:20px;font-weight:700;margin-bottom:10px;color:#f0b429;">⚠ ${title}</div>
    <div style="font-size:14px;line-height:1.6;color:#cfd8e0;white-space:pre-line;">${details}</div>
  </div>`;
  document.body.appendChild(box);
}

function init(){
  try{
    const missingLibs = checkExternalLibs();
    if (missingLibs.length){
      showFatalError(
        'Não foi possível carregar bibliotecas externas',
        `As seguintes bibliotecas não carregaram: ${missingLibs.join(', ')}.\n\nEste dashboard depende de bibliotecas hospedadas em cdnjs.cloudflare.com e precisa de conexão com a internet na primeira vez que a página é aberta (mesmo funcionando 100% localmente depois).\n\nVerifique:\n• Se há conexão com a internet no momento em que a página abriu\n• Se o firewall/rede corporativa não bloqueia cdnjs.cloudflare.com\n• Se está abrindo o arquivo em um navegador (Chrome, Edge, Firefox) e não em um app sem motor de navegação\n\nRecarregue a página após verificar a conexão.`
      );
      return;
    }
    buildDealersIndex();
    wireTabs(); wireSegmentToggle(); wireMasterToggle(); wireFilters(); wireUploads();
    wireStudentModal(); wireExportButton();
    initDealerMultiselect();
    rebuildFilterOptions();
    renderActiveTab();
  }catch(err){
    console.error('Erro fatal na inicialização:', err);
    showFatalError('Ocorreu um erro ao iniciar o dashboard', (err && err.message ? err.message : String(err)) + '\n\nAbra o Console do navegador (F12) para mais detalhes técnicos, ou tente abrir o arquivo em outro navegador (Chrome ou Edge são recomendados).');
  }
}
document.addEventListener('DOMContentLoaded', init);
window.addEventListener('error', (e)=>{
  console.error('Erro não tratado:', e.error || e.message);
});
